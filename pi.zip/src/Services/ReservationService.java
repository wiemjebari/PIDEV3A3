/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import IServices.ServiceInterface;
import Tools.MyConnection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 *
 * @author ASUS
 */
public class ReservationService implements ServiceInterface {
     

    @Override
    public void add(Object t) throws SQLException {
         try {
            String requete = "INSERT INTO ReservationService (id,date,etat)"
                    + "VALUES ('"+t.getId()+"','"+t.getDate()+"','"+t.getEtat())+"')";
            Statement st = MyConnection.getInstance().getCnx()
                    .createStatement();
            st.executeUpdate(requete);
            System.out.println("Reservation ajoutée");
            
        } 
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void delete(int id) throws SQLException {
      
    }

    @Override
    public void update(Object t) throws SQLException {
       
    }

    @Override
    public List readAll() throws SQLException {
       
    }
    

    @Override
    public Object getById(int id) throws SQLException {
        
    }
    
}
