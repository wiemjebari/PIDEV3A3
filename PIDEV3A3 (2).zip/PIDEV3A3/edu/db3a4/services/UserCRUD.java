/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.services;

import edu.db3a4.entities.User;
import edu.db3a4.interfaces.IUser;
import edu.db3a4.tools.MyConnection;
import entities.Recommendation;
import java.sql.Connection;
import java.sql.Date;
import java.time.ZoneId;
import java.time.LocalDate;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class UserCRUD implements IUser<User> {
      Connection cnx;
    Statement stmt;
    private static UserCRUD userservices;
    
     public UserCRUD() {
        this.cnx = MyConnection.getInstance().getCnx();
     }

    @Override
    public void ajouterUser(User t) {
        try {
            String requete = "INSERT INTO user (nom, prenom, sexe, date_naissance, mail"
                    + ", adresse, role, password) VALUES"
                    + " ('" + t.getNom() + "','" + t.getPrenom() + "','" + t.getSexe() + ""
                    + "','" + t.getDate_naiss() + "','" + t.getMail() + "','" + t.getAdresse() + "','" + t.getRole() + ""
                    + "','" + t.getPassword() + "')";
            Statement st = MyConnection.getInstance().getCnx().createStatement();
            st.executeUpdate(requete);
            System.out.println("User ajoutée");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void ajouterUser2(User t) {
        try {
            String requete = "INSERT INTO user(id_client, nom, prenom, sexe, date_naissance, mail, adresse, "
                    + "role, password) VALUES (?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setInt(1, t.getId());
            pst.setString(2, t.getNom());
            pst.setString(3, t.getPrenom());
            pst.setString(4, t.getSexe());
            //Date case
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate l = LocalDate.parse(t.getDate_naiss(), formatter);
            pst.setString(5, l.toString());
            
            
            //*************
            pst.setString(6, t.getMail());
            pst.setString(7, t.getAdresse());
            pst.setString(8, t.getRole());
           
            pst.setString(9, t.getPassword());
            pst.executeUpdate();
            System.out.println("User inserée");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimerUser(User t) {
        try {
            String requete = "DELETE FROM user where id_client=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setInt(1, t.getId());
            pst.executeUpdate();
            System.out.println("User supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    @Override
    public void updateUser(User t) {
        try {
            String requete = "UPDATE user SET nom=?, prenom=?, sexe=?, date_naissance=?, mail=?, adresse=?, role=?, password=? WHERE id_client=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setString(1, t.getNom());
            pst.setString(2, t.getPrenom());
            pst.setString(3, t.getSexe());
            pst.setString(4, t.getDate_naiss().toString());
            pst.setString(5, t.getMail());
            pst.setString(6, t.getAdresse());
            pst.setString(7, t.getRole());
            
            pst.setString(8, t.getPassword());
            pst.setInt(9, t.getId());
            pst.executeUpdate();
            System.out.println("User modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    
    public List<User> displayUsers() {
        List<User> userList = new ArrayList<>();
        try {
            String requete = "SELECT * FROM user";
            Statement st = MyConnection.getInstance().getCnx()
                    .createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                User p = new User();
                p.setId(rs.getInt("id_client"));
                p.setNom(rs.getString("nom"));
                p.setPrenom(rs.getString("prenom"));
                p.setSexe(rs.getString("sexe"));
                p.setDate_naiss(rs.getString("date_naissance"));
                p.setMail(rs.getString("mail"));
                p.setAdresse(rs.getString("adresse"));
                p.setRole(rs.getString("role"));
                
                p.setPassword(rs.getString("password"));
                userList.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return userList;
    }

    @Override
    public boolean verifAdmin(String adresse) {
        ArrayList<User> listN = new ArrayList<User>();
        User u = new User();
        try {
            stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from user where user.`adresse`='"+adresse+"' and user.`role` like '%Admin%' ");
            if(rs.next())
                return true;
            
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(Recommendation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
    }
 public static UserCRUD getInstance() {
        if (userservices == null) {
            return userservices = new UserCRUD();
        }
        return userservices;
    }
    @Override
    public User AfficherUser(String adresse) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean Login(String adresse, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<User> getAllUser() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
