/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.services;

import edu.db3a4.entities.Jeu;
import edu.db3a4.interfaces.IJeu;
import edu.db3a4.tools.MyConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class JeuCRUD implements IJeu<Jeu>{
    
    

    public void ajouterJeu2(Jeu t) {
        try {
            String requete = "INSERT INTO jeux(id, id_client, nom_cat, nom_jeu, niv_diff) VALUES (?,?,?,?,?)";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setInt(1, t.getId());
            pst.setInt(2, t.getId_client());
            pst.setString(3, t.getNom_cat());
            pst.setString(4, t.getNom_jeu());
            pst.setInt(5, t.getNiv_diff());
            pst.executeUpdate();
            System.out.println("Jeu inserée");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void supprimerJeu(Jeu t) {
        try {
            String requete = "DELETE FROM jeux where id=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setInt(1, t.getId());
            pst.executeUpdate();
            System.out.println("Jeu supprimée!");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void updateJeu(Jeu t) {
        try {
            String requete = "UPDATE jeux SET nom_cat=?, nom_jeu=?, niv_diff=? WHERE id=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setString(1, t.getNom_cat());
            pst.setString(2, t.getNom_jeu());
            pst.setInt(3, t.getNiv_diff());
            pst.setInt(4, t.getId());
            pst.executeUpdate();
            System.out.println("Jeu modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     *
     * @return
     */
    public List<Jeu> displayJeu() {
        List<Jeu> jeuList = new ArrayList<>();
        try {
            String requete = "SELECT * FROM jeux";
            Statement st = MyConnection.getInstance().getCnx()
                    .createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                Jeu p = new Jeu();
                p.setId(rs.getInt("id"));
                p.setId_client(rs.getInt("id_client"));
                p.setNom_cat(rs.getString("nom_cat"));
                p.setNom_jeu(rs.getString("nom_jeu"));
                p.setNiv_diff(rs.getInt("niv_diff"));
                jeuList.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return jeuList;
    }
    
    
    
    
    public int getlastID() {
        JeuCRUD jcd = new JeuCRUD();
        List<Jeu> listj = jcd.displayJeu();       
        return listj.size()+1;
    }
    
    public void ajouterJeu(Jeu t) {
        try {
            String requete = "INSERT INTO jeux (id_client, nom_cat, nom_jeu, niv_diff) VALUES"
                    + " ('" + t.getId_client() + "','" + t.getNom_cat() + "','" + t.getNom_jeu() + "','" + t.getNiv_diff()+ "')";
            Statement st = MyConnection.getInstance().getCnx().createStatement();
            st.executeUpdate(requete);
            System.out.println("Jeu ajoutée");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }
}
