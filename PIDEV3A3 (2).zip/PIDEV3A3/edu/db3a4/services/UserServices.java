/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.services;

  
import entities.Recommendation;
import edu.db3a4.entities.User;
import tools.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import edu.db3a4.interfaces.IUser;

/**
 *
 * @author wiemj
 */


/**
 *
 * @author Achraf
 */
public class UserServices implements IUser<User> {
    Connection cnx;
    Statement stmt;
    private static UserServices userservices;
    
     public UserServices() {
        this.cnx = MyConnection.getInstance().getCnx();

    }
    @Override
    public void ajouterUser(User t) {
        try {
            String requete = "INSERT INTO user (nom, prenom, sexe, date_naissance, mail"
                    + ", adresse, role, password) VALUES"
                    + " ('" + t.getNom() + "','" + t.getPrenom() + "','" + t.getSexe() + ""
                    + "','" + t.getDate_naiss() + "','" + t.getMail() + "','" + t.getAdresse() + "','" + t.getRole() + ""
                    +  "','" + t.getPassword() + "')";
            Statement st = MyConnection.getInstance().getCnx().createStatement();
            st.executeUpdate(requete);
            System.out.println("User ajoutée");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void ajouterUser2(User t) {
        try {
            String requete = "INSERT INTO user(id_client, nom, prenom, sexe, date_naissance, mail, adresse, "
                    + "role, password) VALUES (?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setInt(1, t.getId());
            pst.setString(2, t.getNom());
            pst.setString(3, t.getPrenom());
            pst.setString(4, t.getSexe());
            pst.setString(5, t.getDate_naiss().toString());
            pst.setString(6, t.getMail());
            pst.setString(7, t.getAdresse());
            pst.setString(8, t.getRole());
            
            pst.setString(9, t.getPassword());
            pst.executeUpdate();
            System.out.println("User inserée");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimerUser(User t) {
        try {
            String requete = "DELETE FROM user where id_client=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setInt(1, t.getId());
            pst.executeUpdate();
            System.out.println("User supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    @Override
    public void updateUser(User t) {
        try {
            String requete = "UPDATE user SET nom=?, prenom=?, sexe=?, date_naissance=?, mail=?, adresse=?, role=?, password=? WHERE id_user=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setString(1, t.getNom());
            pst.setString(2, t.getPrenom());
            pst.setString(3, t.getSexe());
            pst.setString(4, t.getDate_naiss().toString());
            pst.setString(5, t.getMail());
            pst.setString(6, t.getAdresse());
            pst.setString(7, t.getRole());

            pst.setString(8, t.getPassword());
            pst.setInt(9, t.getId());
            pst.executeUpdate();
            System.out.println("User modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    
    public List<User> displayUsers() {
        List<User> userList = new ArrayList<>();
        try {
            String requete = "SELECT * FROM user";
            Statement st = MyConnection.getInstance().getCnx()
                    .createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                User p = new User();
                p.setId(rs.getInt("id_user"));
                p.setNom(rs.getString("nom"));
                p.setPrenom(rs.getString("prenom"));
                p.setSexe(rs.getString("sexe"));
               p.setDate_naiss(rs.getString("date_naissance"));
                p.setMail(rs.getString("mail"));
                p.setAdresse(rs.getString("adresse"));
                p.setRole(rs.getString("role"));

                p.setPassword(rs.getString("password"));
                userList.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return userList;
    }
    public User AfficherUserId(int id) {
 ArrayList<User> listN = new ArrayList<User>();
 User u = new User();
        try {
            stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from user where user.`id_client`='"+id+"'");
            while (rs.next()) {
                System.out.println("id_client " + rs.getString(1) + "contenu  " + rs.getString(4));
                u.setId(rs.getInt(1));
                        
                        u.setMail(rs.getString(6));
                        u.setSexe(rs.getString(3));
                        u.setAdresse(rs.getString(7));
                        u.setPassword(rs.getString(9));
                        u.setDate_naiss(rs.getString(5));
                        u.setNom(rs.getString(2));
                        u.setPrenom(rs.getString(3));
                         u.setRole(rs.getString(8));
                       
          
                        
            }
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(Recommendation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return u;
    }
    
    
    @Override
    public boolean verifAdmin(String adresse) {
        ArrayList<User> listN = new ArrayList<User>();
 User u = new User();
        try {
            stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from user where user.`adresse`='"+adresse+"' and user.`role` like '%Admin%' ");
            if(rs.next())
                return true;
            
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(Recommendation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
    }
 public static UserServices getInstance() {
        if (userservices == null) {
            return userservices = new UserServices();
        }
        return userservices;
    }
@Override
    public User AfficherUser(String adresse) {
 ArrayList<User> listN = new ArrayList<User>();
 User u = new User();
        try {
            stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from user where user.`adresse`='"+adresse+"'");
            while (rs.next()) {
                System.out.println("id_user " + rs.getString(1) + "contenu  " + rs.getString(4));
                u.setId(rs.getInt(1));

                        u.setMail(rs.getString(6));
                        u.setSexe(rs.getString(3));
                        u.setAdresse(rs.getString(7));
                        u.setPassword(rs.getString(9));
                        u.setDate_naiss(rs.getString(5));
                        u.setNom(rs.getString(2));
                        u.setPrenom(rs.getString(3));
                       u.setRole(rs.getString(8));

            }
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(Recommendation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return u;
    }
    
    @Override
    public Boolean Login(String adresse, String password) {

        try {
            stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from user WHERE user.`adresse` = '" + adresse + "'and  user.`password` like '"+password+"%'");
            
            if (rs.next()) {
                System.out.println("login success");
                return true;
            }
            

            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    @Override
    public List<User> getAllUser() {
        ArrayList<User> listN = new ArrayList<User>();
        try {
            stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from user");
            while (rs.next()) {
                System.out.println("id_client " + rs.getString(1) + "contenu  " + rs.getString(4));
                listN.add(new User(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9)
                      
                ));
            }
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(Recommendation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listN;
    }



   

}
