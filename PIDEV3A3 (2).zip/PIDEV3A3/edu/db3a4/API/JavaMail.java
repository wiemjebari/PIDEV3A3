/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.API;

/**
 *
 * @author HP
 */
//if a problem occurs don't forget to turn google security less off again.
public class JavaMail {
    public static void main(String[] args) throws Exception {
        JavaMailUtil.sendMail("nightmarezex@gmail.com","thedance46");
    }
}
