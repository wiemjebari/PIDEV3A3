/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.API;

import java.io.*;
import java.lang.*;
import java.util.*;

/**
 *
 * @author HP
 */
public class createfile {
    
    private Formatter x;
    
    public void openFile(){
        try{
            x = new Formatter("Score.txt");
        }
        catch(Exception e){
            System.out.println("You have an error");
        }
    }
    
    public void addRecords(){
        x.format("%s%s%s", "20 ", "bucky", "robetrs");
    }
    
    public void closeFile(){
        x.close();
    }
    
    
    public static void main(String[] args) {
        
        createfile g = new createfile();
        g.openFile();
        g.addRecords();
        g.closeFile();
        
    }
}
