/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.API;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *
 * @author HP
 */
public class Chart {

    public Chart() {
        CreateChart f1 = new CreateChart("Pie Chart Tes", "OS Comparision",6,8,4);

        f1.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }

        });

    }

    public static void main(String[] args) {

        CreateChart frame = new CreateChart("Pie Chart Tes", "OS Comparision",6,8,4);

    }
}
