/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import edu.db3a4.entities.User;
import edu.db3a4.services.UserCRUD;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class MainMenuController4 implements Initializable{

    @FXML
    private TableView<User> table;

    @FXML
    private TableColumn<User, Integer> id;

    @FXML
    private TableColumn<User, String> nom;

    @FXML
    private TableColumn<User, String> pre;

    @FXML
    private TableColumn<User, String> se;

    @FXML
    private TableColumn<User, String> dat;

    @FXML
    private TableColumn<User, String> mai;

    @FXML
    private TableColumn<User, String> ad;

    @FXML
    private TableColumn<User, String> ro;

    @FXML
    private TableColumn<User, String> pwd;

    @FXML
    private Button btndi;
    
    @FXML
    private ComboBox<Integer> combo1;
    
    UserCRUD cd = new UserCRUD();
    List<User> list0 = cd.displayUsers();
    ObservableList<User> list = FXCollections.observableArrayList();
    ObservableList<Integer> list2 = FXCollections.observableArrayList(1,2);
    
    public void initialize(URL url, ResourceBundle rb) {
        
        id.setCellValueFactory(new PropertyValueFactory<User,Integer>("id"));
        combo1.setItems(list2);
        
    }

    @FXML
    void Display2(ActionEvent event) {    
        table.getItems().clear();
        list0 = cd.displayUsers();
        list.addAll(list0);
        table.setItems(list);
    }

}

