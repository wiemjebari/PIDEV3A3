/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import edu.db3a4.entities.User;
import edu.db3a4.services.UserCRUD;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class RegistrationController implements Initializable{

    @FXML
    private AnchorPane rootPane6;

    @FXML
    private ImageView imgvi1;

    @FXML
    private TextField tfid1;
    
    @FXML
    private TextField tfnom1;

    @FXML
    private TextField tfprenom1;

    @FXML
    private ComboBox<String> tfsexe1;

    @FXML
    private DatePicker tfdaten1;

    @FXML
    private TextField tfmail1;

    @FXML
    private TextField tfad1;

    @FXML
    private ComboBox<String> tfrole1;
     

    @FXML
    private PasswordField tfpwd1;

    @FXML
    private Button btna1;

    @FXML
    private Button tfback;
    
    
    UserCRUD cd = new UserCRUD();
    List<User> list0 = cd.displayUsers();
    ObservableList<User> list = FXCollections.observableArrayList();
    ObservableList<String> list1 = FXCollections.observableArrayList("Homme","Femme");
    ObservableList<String> list2 = FXCollections.observableArrayList("Admin","Client");
    ObservableList<String> list6 =
            FXCollections.observableArrayList("By Cli name ascendant","By Cli name descendant",
    "By Cli surname ascendant","By Cli surname descendant");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
    User u;
    

    @FXML
    void loadback(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GeneralMainPackage/Entry.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
           
        ObservableList<String> list1 = FXCollections.observableArrayList("Homme","Femme");
        tfsexe1.setItems(list1);
        ObservableList<String> list2 = FXCollections.observableArrayList("Admin","Client");
        tfrole1.setItems(list2);        
        
    }
    
    @FXML
    private void ajouterUser(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB
           /* if(tfid.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Fill all info!");
            }*/
            /*list0 = cd.displayUsers();
            int resIdc1 = Integer.parseInt(tfid.getText());
            u.setId(resIdc1);
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == u.getId())
                    JOptionPane.showMessageDialog(null, "Client already exists!");
            }
            if(!((resIdc1 > 0) && (resIdc1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }*/
            boolean test=false;
            if(tfnom1.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's Name!");
            }
            if(tfprenom1.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's Surname!");
            }
            
            if(tfdaten1.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Fill Client's date!");
            }
            if(tfmail1.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's mail ID!");
            }
            if(tfad1.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's adresse");
            }
            if(!tfad1.getText().contains("@")){
                JOptionPane.showMessageDialog(null, "Not a valid addresse");
            }
            
            if(tfrole1.getSelectionModel().getSelectedItem().equals("Admin")){
            
                if(!tfpwd1.getText().contains("01")){
                    JOptionPane.showMessageDialog(null, "An administrator's password must contain '01'");
                    test=false;
                }
                else
                {
                    test=true;
                }
            }
            if(tfrole1.getSelectionModel().getSelectedItem().equals("Client")){
                if(!tfpwd1.getText().contains("05")){
                    JOptionPane.showMessageDialog(null, "A client's password must contain '05'");
                    test=false;
                }
                else
                {
                    test=true;
                }
            }
            list0 = cd.displayUsers();
            
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getAdresse().equals(tfad1.getText()))
                    JOptionPane.showMessageDialog(null, "Address already exists!");
            }
            /*if(tfrole.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid Role!");
            }*/
            if(tfpwd1.getText().isEmpty() || (test == false)) {
                JOptionPane.showMessageDialog(null, "Fill Client's password!");
            }
            else{
            //String resId = tfid.getText();
            String resNom = tfnom1.getText();
            String resPrenom = tfprenom1.getText();
            String resSexe = tfsexe1.getValue();
            String resDaten = tfdaten1.getValue().toString();
            String resMail = tfmail1.getText();
            String resAdresse = tfad1.getText();
            String resRole = tfrole1.getValue();
            
            String resPass = tfpwd1.getText();
            User u = new User(resNom,resPrenom,resSexe,resDaten,resMail,
                                                                    resAdresse,resRole,resPass);
            
                UserCRUD cd = new UserCRUD();
            cd.ajouterUser2(u);
            JOptionPane.showMessageDialog(null, "User ajouté");
            }
            
            
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("Registration.fxml"));
            Parent root = loader.load();
            edu.db3a4.gui.UserDetailsController uct = loader.getController();
            uct.setrId(tfid1.getText());
            uct.setrNom(tfnom1.getText());
            uct.setrPrenom(tfprenom1.getText());
            uct.setRsexe(tfsexe1.getValue());
            uct.setRdate_naiss(tfdaten1.getValue());
            uct.setRmail(tfmail1.getText());
            uct.setRaddresse(tfad1.getText());
            uct.setRrole(tfrole1.getValue());
           
            uct.setRpassword(tfpwd1.getText());
            tfid1.getScene().setRoot(root);
            
        } catch (IOException e) {
            System.out.println("User not Added!");
        }
    }
    
}
