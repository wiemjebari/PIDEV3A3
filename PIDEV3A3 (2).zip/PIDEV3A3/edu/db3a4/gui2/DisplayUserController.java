/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

/**
 *
 * @author ASUS
 */
public class DisplayUserController implements Initializable {

    @FXML
    private TextField rid;

    @FXML
    private TextField rnom;

    @FXML
    private TextField rpre;

    @FXML
    private TextField rsexe;

    @FXML
    private TextField rdate_naiss;

    @FXML
    private TextField rmail;

    @FXML
    private TextField raddresse;

    @FXML
    private TextField rrole;

    @FXML
    private TextField rpassword;
 

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    public void setRid(String value) {
        this.rid.setText(value);
    }
    
    public void setrNom(String value) {
        this.rnom.setText(value);
    }

    public void setrPrenom(String value) {
        this.rpre.setText(value);
    }

    public void setRsexe(String value) {
        this.rsexe.setText(value);
    }

    public void setRdate_naiss(String value) {
        this.rdate_naiss.setText(value);
    }

    public void setRmail(String value) {
        this.rmail.setText(value);
    }

    public void setRaddresse(String value) {
        this.raddresse.setText(value);
    }

    public void setRrole(String value) {
        this.rrole.setText(value);
    }
   
    public void setRpassword(String value) {
        this.rpassword.setText(value);
    }

}
