/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import edu.db3a4.API.CreateChart;
import edu.db3a4.entities.Jeu;
import edu.db3a4.entities.User;
import edu.db3a4.services.JeuCRUD;
import edu.db3a4.services.UserCRUD;
import edu.db3a4.tools.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.controlsfx.control.Notifications;

/**
 *
 * @author HP
 */
public class BackJeuController implements Initializable{

    @FXML
    private AnchorPane rootPane7;

    @FXML
    private ImageView imgvi;

    @FXML
    private TableView<Jeu> table1;

    @FXML
    private TableColumn<Jeu, Integer> idd;
   
    @FXML
    private TableColumn<Jeu, Integer> idcc;

    @FXML
    private TableColumn<Jeu, String> ncc;

    @FXML
    private TableColumn<Jeu, String> njc;

    @FXML
    private TableColumn<Jeu, Integer> ndc;
   
    @FXML
    private TextField tfid1;

    @FXML
    private ComboBox<Integer> tfidc11;

    @FXML
    private ComboBox<String> tfnomc1;

    @FXML
    private ComboBox<String> tfnomj1;

    @FXML
    private ComboBox<Integer> combo1;

    @FXML
    private Button btna1;

    @FXML
    private Button btnu1;

    @FXML
    private Button btnde1;

    @FXML
    private Button btnfi1;

    @FXML
    private TextField tfid21;

    @FXML
    private Button btnso1;

    @FXML
    private ComboBox<String> typ1;

    @FXML
    private Button tfback1;

   
    JeuCRUD jcd = new JeuCRUD();
    List<Jeu> list0;  
    ObservableList<Jeu> list = FXCollections.observableArrayList();
    ObservableList<Jeu> list4 = FXCollections.observableArrayList();
    ObservableList<String> list5 =
            FXCollections.observableArrayList("By Cli name ascendant","By Cli name descendant",
    "By Game's name ascendant","By Game's name descendant",
    "By Difficuly level ascendant","By Difficuly level descendant");
    Jeu j = new Jeu(1,3,"Aile","Checkers",1);
    UserCRUD cd = new UserCRUD();
    List<User> listc = cd.displayUsers();
    int x=0,y=0,z=0;
   
   
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        idd.setCellValueFactory(new PropertyValueFactory<Jeu,Integer>("id"));
        idcc.setCellValueFactory(new PropertyValueFactory<Jeu,Integer>("id_client"));
        ncc.setCellValueFactory(new PropertyValueFactory<Jeu,String>("nom_cat"));
        njc.setCellValueFactory(new PropertyValueFactory<Jeu,String>("nom_jeu"));
        ndc.setCellValueFactory(new PropertyValueFactory<Jeu,Integer>("niv_diff"));
       
        /*list.add(j);
        list.addAll(list0);
        table.setItems(list);*/
        ObservableList<Integer> list1 = FXCollections.observableArrayList(1,2,3);
        combo1.setItems(list1);
        ObservableList<Integer> list2 = FXCollections.observableArrayList();
        tfidc11.setItems(list2);
        typ1.setItems(list5);
       
       
        ObservableList<String> list6
                = FXCollections.observableArrayList("Adventure", "Sports", "Yoga");
        ObservableList<String> list7
                = FXCollections.observableArrayList("Ping-Pong", "Snake", "Green-Hill");
        tfnomc1.setItems(list6);
        tfnomj1.setItems(list7);
       
       
        for(int i=0;i<listc.size();i++){
            list2.add(listc.get(i).getId());
        }
        table1.getItems().clear();
        list0 = jcd.displayJeu();
        list.addAll(list0);
        table1.setItems(list);  
       
        for(int i=0;i<list0.size();i++){
            if(list0.get(i).getNiv_diff() == 1) {
                x++;
            }
            else if(list0.get(i).getNiv_diff() == 2) {
                y++;
            }
            else if(list0.get(i).getNiv_diff() == 3) {
                z++;
            }
        }
    }
   
   
    @FXML
    public void Notificationget(){
        Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Adresse/Password invalide!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.show();
    }
   
       
    @FXML
    private void Delete1() throws IOException {
        ObservableList<Jeu> selectedgame=table1.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selectedgame.get(0).getId());
        try {
            String requete = "DELETE FROM jeux where id=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            if(table1.getSelectionModel().getSelectedItem().toString() == null){
                //JOptionPane.showMessageDialog(null, "Select Game!");
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Select Game!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }  
                  pst.setString(1, y);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Jeu Supprimé");
            System.out.println("Jeu supprimée!");
            table1.getItems().clear();
            list0 = jcd.displayJeu();
            list.addAll(list0);
            table1.setItems(list);
            for(int i=0;i<table1.getItems().size(); i++){
                table1.getSelectionModel().getSelectedItems().get(i).setId(
                table1.getSelectionModel().getSelectedIndex());
            }
               
           
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @FXML
    public void Rechercher1() throws IOException{      
        try {
            if(tfid21.getText().isEmpty()){
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Adresse/Password invalide!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.darkStyle();
    notificationBuilder.showError();
            }
            String requete = "SELECT * FROM jeux WHERE id='"+ tfid21.getText() +"'";
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                Jeu p = new Jeu();
                p.setId(rs.getInt("id"));
                p.setId_client(rs.getInt("id_client"));
                p.setNom_cat(rs.getString("nom_cat"));
                p.setNom_jeu(rs.getString("nom_jeu"));
                p.setNiv_diff(rs.getInt("niv_diff"));
                //jeuList.add(p);
                list4.add(p);
            }
            table1.getItems().clear();
               
                table1.setItems(list4);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }

    @FXML
    private void Trier1()  throws IOException{
        List<Jeu> jeuList = new ArrayList<>();
        try {
            if(typ1.getSelectionModel().isEmpty())
            {
                //JOptionPane.showMessageDialog(null, "Choose sort type!");
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Choose sort type!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
           
            String requete = "SELECT * FROM jeux";
           
            if(typ1.getSelectionModel().getSelectedItem().equals("By Cli name ascendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_cat ASC";
            }
            if(typ1.getSelectionModel().getSelectedItem().equals("By Cli name descendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_cat DESC";
            }
            if(typ1.getSelectionModel().getSelectedItem().equals("By Game's name ascendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_jeu ASC";
            }
            if(typ1.getSelectionModel().getSelectedItem().equals("By Game's name descendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_jeu DESC";
            }
            if(typ1.getSelectionModel().getSelectedItem().equals("By Difficuly level ascendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY niv_diff ASC";
            }
            if(typ1.getSelectionModel().getSelectedItem().equals("By Difficuly level descendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY niv_diff DESC";
            }
           
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                Jeu t = new Jeu();
                t.setId(rs.getInt("id"));
                t.setId_client(rs.getInt("id_client"));
                t.setNom_cat(rs.getString("nom_cat"));
                t.setNom_jeu(rs.getString("nom_jeu"));
                t.setNiv_diff(rs.getInt("niv_diff"));
                jeuList.add(t);
               
            }
            table1.getItems().clear();
                list.addAll(jeuList);                
                table1.setItems(list);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }

    @FXML
    private void Update1() throws IOException {
        ObservableList<Jeu> selectedgame=table1.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selectedgame.get(0).getId());
        try {
            /*if(tfid.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill ID!");
            } */
            if(tfidc11.getSelectionModel().isEmpty()){
            //JOptionPane.showMessageDialog(null, "Fill ID_Client!");
            Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill ID_Client!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.show();
            }            
            list0 = jcd.displayJeu();
            int resId1 = Integer.parseInt(y);//(tfid.getText());
            j.setId(resId1);
            boolean test=false;
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == j.getId())
                    test=true;            
            }
            if(test == false){
                //JOptionPane.showMessageDialog(null, "Game dosen't exists!");
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Game dosen't exists!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            if(!((resId1 > 0) && (resId1 < 500))) {
                //JOptionPane.showMessageDialog(null, "Invalid ID!");
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Invalid ID!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            if(tfnomc1.getSelectionModel().isEmpty()){
            //JOptionPane.showMessageDialog(null, "Fill Client's name!");
            Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill Client's name!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            else if(tfnomj1.getSelectionModel().isEmpty()){
            //JOptionPane.showMessageDialog(null, "Fill Game's name!");
            Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill Game's name!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            /*else if(tfniv.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill Difficuty level!");    
            }*/
            else if(combo1.getSelectionModel().isEmpty())
            {
                //JOptionPane.showMessageDialog(null, "Fill Difficuty level!");  
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill Difficuty level!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            else {
            String requete = "UPDATE jeux SET nom_cat=?, nom_jeu=?, niv_diff=?, id_client=? WHERE id=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setString(1, tfnomc1.getSelectionModel().getSelectedItem());
            pst.setString(2, tfnomj1.getSelectionModel().getSelectedItem());
            //pst.setString(3, tfniv.getText());
            pst.setString(3, combo1.getSelectionModel().getSelectedItem().toString());
            pst.setString(4, tfidc11.getSelectionModel().getSelectedItem().toString());
            pst.setString(5, y);//tfid.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Jeu modifiée!");
            System.out.println("Jeu modifiée!");
            table1.getItems().clear();
            list0 = jcd.displayJeu();
            list.addAll(list0);
            table1.setItems(list);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
   
    @FXML
    private int getlastID(){
        JeuCRUD jcd = new JeuCRUD();
        List<Jeu> listj = jcd.displayJeu();      
        return listj.size()+1;
    }

    @FXML
    private void ajouterJeu(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB
            /*if(tfid.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill ID!");
            }*/
            if(tfidc11.getSelectionModel().isEmpty()){
            //JOptionPane.showMessageDialog(null, "Fill ID_Client!");
            Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill ID_Client!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
             list0 = jcd.displayJeu();
            //int resId1 = Integer.parseInt(tfid.getText());
            int resId1 = getlastID();
            j.setId(resId1);
            /*for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == j.getId())
                    JOptionPane.showMessageDialog(null, "Game already exists!");
            }*/
            /*if(list0.contains(tfid.getText())){
                JOptionPane.showMessageDialog(null, "Game already exists!");
            }*/
            /*if(!((resId1 > 0) && (resId1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }*/
            if(tfnomc1.getSelectionModel().isEmpty()){
            //JOptionPane.showMessageDialog(null, "Fill Client's name!");
            Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill Client's name!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            else if(tfnomj1.getSelectionModel().isEmpty()){
            //JOptionPane.showMessageDialog(null, "Fill Game's name!");    
            Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill Game's name!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            /*else if(tfniv.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill Difficuty level!");    
            }*/
            else if(combo1.getSelectionModel().isEmpty())
            {
                //JOptionPane.showMessageDialog(null, "Fill Difficuty level!");    
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill Difficuty leve!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            else {
            String resIdc = tfidc11.getSelectionModel().getSelectedItem().toString();
            String resNomc = tfnomc1.getSelectionModel().getSelectedItem();
            String resNomj = tfnomj1.getSelectionModel().getSelectedItem();
            //String resNiv = tfniv.getText();
            //int resNiv1 = Integer.parseInt(resNiv);
            int resIdc1 = Integer.parseInt(tfidc11.getSelectionModel().getSelectedItem().toString());
            int resNiv1 = Integer.parseInt(combo1.getSelectionModel().getSelectedItem().toString());
           
           
            Jeu j = new Jeu(resId1,resIdc1,resNomc,resNomj,resNiv1);            
            JeuCRUD jcd = new JeuCRUD();
            jcd.ajouterJeu(j);
            JOptionPane.showMessageDialog(null, "Jeu ajouté");
            table1.getItems().clear();
            list0 = jcd.displayJeu();
            list.addAll(list0);
            table1.setItems(list);
           
           
           
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("backjeux.fxml"));
            Parent root = loader.load();
            JeuDetailsController uct = loader.getController();
            //uct.setrId(tfidc1.getSelectionModel().getSelectedItem().toString());
            uct.setrNomc(tfnomc1.getSelectionModel().getSelectedItem());
            uct.setrNomj(tfnomj1.getSelectionModel().getSelectedItem());
            //uct.setrNom(tfniv.getText());
            uct.setrNiv(combo1.getSelectionModel().getSelectedItem());
            tfid1.getScene().setRoot(root);
            }
           
        } catch (IOException e) {
            System.out.println("Game not Added!");
        }
    }

    @FXML
    void loadback(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GeneralMainPackage/GeneralBackPage.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }
   
   
     
    @FXML
    void chartdiff(){
        x=y=z=0;
        table1.getItems().clear();
        list0 = jcd.displayJeu();
        list.addAll(list0);
        table1.setItems(list);
       
        for(int i=0;i<list0.size();i++){
            if(list0.get(i).getNiv_diff() == 1) {
                x++;
            }
            else if(list0.get(i).getNiv_diff() == 2) {
                y++;
            }
            else if(list0.get(i).getNiv_diff() == 3) {
                z++;
            }
        }
       
        CreateChart CC = new CreateChart("Pie Chart Jeux", "Difficulty Comparision",x,y,z);
        CC.pack();
        CC.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        CC.setVisible(true);
        System.out.println(x);System.out.println(y);System.out.println(z);
       
    }
   
}

