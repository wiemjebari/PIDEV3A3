/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import edu.db3a4.gui.*;
import edu.db3a4.entities.User;
import edu.db3a4.services.UserCRUD;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.TextField;

/**
 *
 * @author HP
 */
public class DisplayUserControllerf {

    @FXML
    private TextField tfId;
    @FXML
    private TextField tfNom;
    @FXML
    private TextField tfPrenom;
    @FXML
    private TextField tfsexe;
    @FXML
    private TextField tfdate_naiss;
    @FXML
    private TextField tfmail;
    @FXML
    private TextField tfaddresse;
    @FXML
    private TextField tfrole;
    @FXML
    private TextField tfpassword;

    
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    public void displayUser(){
        try {
            UserCRUD jcd = new UserCRUD();
            List<User> list = jcd.displayUsers();
            Iterator<User> i = list.iterator();
            ////New Code here
            
            while(i.hasNext()){
                System.out.println(i.next());
            }
            
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("UserDetails.fxml"));
            Parent root = loader.load();
            UserDetailsController uct = loader.getController();
            uct.setrNom(tfNom.getText());
            uct.setrPrenom(tfPrenom.getText());
            uct.setRsexe(tfsexe.getText());
           // uct.setRdate_naiss(tfdate_naiss.getText());
            uct.setRmail(tfmail.getText());
            uct.setRaddresse(tfaddresse.getText());
            uct.setRrole(tfrole.getText());
          
            uct.setRpassword(tfpassword.getText());
            tfId.getScene().setRoot(root);
            
            
        } catch (IOException e) {
            System.out.println("User not Displayed!");
        }
    } 
    
}
