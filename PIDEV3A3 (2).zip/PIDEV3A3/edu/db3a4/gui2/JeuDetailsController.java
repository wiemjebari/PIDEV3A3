/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

/**
 *
 * @author ASUS
 */
public class JeuDetailsController {
     
    //@FXML
    //private TextField rId;
    @FXML
    private TextField rNomc;

    @FXML
    private TextField rNomj;

    @FXML
    private ComboBox<Integer> rIdc;

    @FXML
    private ComboBox<Integer> rNiv;
    

    /**
     * Initializes the controller class.
     */
    public void initialize(URL url, ResourceBundle rb) {

    }

    /*public void setrId(String value) {
        this.rId.setText(value);
    }*/

    public void setrIdc(Integer value) {
        this.rIdc.setValue(value);
    }

    public void setrNomc(String value) {
        this.rNomc.setText(value);
    }

    public void setrNomj(String value) {
        this.rNomj.setText(value);
    }

    public void setrNiv(Integer value) {
        this.rNiv.setValue(value);
    }

    
    
}
