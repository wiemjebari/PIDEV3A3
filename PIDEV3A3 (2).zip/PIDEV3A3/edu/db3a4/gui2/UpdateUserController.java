/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;


import edu.db3a4.gui.*;
import edu.db3a4.entities.User;
import edu.db3a4.services.UserCRUD;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

public class UpdateUserController {
    
    private TextField tfId;
    @FXML
    private TextField tfNom;
    @FXML
    private TextField tfPrenom;
    @FXML
    private TextField tfsexe;
    @FXML
    private TextField tfdate_naiss;
    @FXML
    private TextField tfmail;
    @FXML
    private TextField tfaddresse;
    @FXML
    private TextField tfrole;
    @FXML
    private TextField tfpassword;
    @FXML
    private Button btnAdd;
   

    /**
     * Initializes the controller class.
     */
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void updateUser(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB
            String resId = tfId.getText();
            String resNom = tfNom.getText();
            String resPrenom = tfPrenom.getText();
            String resSexe = tfsexe.getText();
            String resDate_naiss = tfdate_naiss.getText();
            String resMail = tfmail.getText();
            String resAdresse = tfaddresse.getText();
            String resRole = tfrole.getText();
           
            String resPassword = tfpassword.getText();
            User u = new User(20,resNom,resPrenom,resSexe,resDate_naiss,resMail,resAdresse,resRole,
                             resPassword);
            UserCRUD ucd = new UserCRUD();
            ucd.updateUser(u);
            JOptionPane.showMessageDialog(null, "User modifié");
            
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("UserDetails.fxml"));
            Parent root = loader.load();
            UserDetailsController uct = loader.getController();
            uct.setrNom(tfNom.getText());
            uct.setrPrenom(tfPrenom.getText());
            uct.setrNom(tfsexe.getText());
            uct.setrNom(tfdate_naiss.getText());
            uct.setrNom(tfmail.getText());
            uct.setrNom(tfaddresse.getText());
            uct.setrNom(tfrole.getText());
       
            uct.setrNom(tfpassword.getText());
            tfPrenom.getScene().setRoot(root);
            
        } catch (IOException ex) {
            Logger.getLogger(AddUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
