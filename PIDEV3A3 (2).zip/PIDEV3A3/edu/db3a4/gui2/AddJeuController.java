/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import edu.db3a4.gui.*;
import edu.db3a4.entities.Jeu;
import edu.db3a4.services.JeuCRUD;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class AddJeuController {
    @FXML
    private TextField tfId;
    @FXML
    private TextField tfIdc;
    @FXML
    private TextField tfnomc;
    @FXML
    private TextField tfnomj;
    @FXML
    private TextField tfniv;
    @FXML
    private Button tfBtn;
    
    
    /**
     * Initializes the controller class.
     */
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void ajouterJeu(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB
            String resId = tfId.getText();
            String resIdc = tfIdc.getText();
            String resNomc = tfnomc.getText();
            String resNomj = tfnomj.getText();
            String resNiv = tfniv.getText();
            int resId1 = Integer.parseInt(resIdc);
            int resIdc1 = Integer.parseInt(resIdc);
            int resNiv1 = Integer.parseInt(resNiv);
            Jeu j = new Jeu(resId1,resIdc1,resNomc,resNomj,resNiv1);
            JeuCRUD jcd = new JeuCRUD();
            jcd.ajouterJeu(j);
            JOptionPane.showMessageDialog(null, "Jeu ajouté");
            
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("JeuDetails.fxml"));
            Parent root = loader.load();
            edu.db3a4.gui.JeuDetailsController uct = loader.getController();
           // uct.setrId(tfIdc.getText());
           // uct.setrNom(tfnomc.getText());
           // uct.setrPrenom(tfnomj.getText());
           // uct.setrNom(tfniv.getText());
            tfIdc.getScene().setRoot(root);
            
        } catch (IOException e) {
            System.out.println("Game not Added!");
        }
    }
}
