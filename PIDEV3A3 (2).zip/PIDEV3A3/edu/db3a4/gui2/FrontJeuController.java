/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui2;

import edu.db3a4.API.JavaMailUtil;
import edu.db3a4.entities.Jeu;
import edu.db3a4.entities.User;
import edu.db3a4.services.JeuCRUD;
import edu.db3a4.services.UserCRUD;
import edu.db3a4.tools.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.JOptionPane;
import mini.game.proto.GameFrame;
import org.controlsfx.control.Notifications;


/**
 *
 * @author HP
 */
public class FrontJeuController implements Initializable{

    @FXML
    private AnchorPane rootPane8;

    @FXML
    private ImageView imgvi;

    @FXML
    private TableView<Jeu> table11;

    @FXML
    private TableColumn<Jeu, Integer> idd;

    @FXML
    private TableColumn<Jeu, Integer> idcc;

    @FXML
    private TableColumn<Jeu, String> ncc;

    @FXML
    private TableColumn<Jeu, String> njc;

    @FXML
    private TableColumn<Jeu, Integer> ndc;

    @FXML
    private Button btnfi11;

    @FXML
    private TextField tfid211;
   
    @FXML
    private TextField tfidc11;
   
    @FXML
    private TextField sfad;

    @FXML
    private PasswordField sfpwd;
   
    @FXML
    private Button btnso11;

    @FXML
    private ComboBox<String> typ11;

    @FXML
    private Button tfback1;
   
    JeuCRUD jcd = new JeuCRUD();
    List<Jeu> list0;
    ObservableList<Jeu> list = FXCollections.observableArrayList();
    ObservableList<Jeu> list4 = FXCollections.observableArrayList();
    ObservableList<String> list5 =
            FXCollections.observableArrayList("By Cli name ascendant","By Cli name descendant",
    "By Game's name ascendant","By Game's name descendant",
    "By Difficuly level ascendant","By Difficuly level descendant");
    Jeu j = new Jeu(1,3,"Aile","Checkers",1);
    UserCRUD cd = new UserCRUD();
    List<User> listc = cd.displayUsers();
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        idd.setCellValueFactory(new PropertyValueFactory<Jeu,Integer>("id"));
        idcc.setCellValueFactory(new PropertyValueFactory<Jeu,Integer>("id_client"));
        ncc.setCellValueFactory(new PropertyValueFactory<Jeu,String>("nom_cat"));
        njc.setCellValueFactory(new PropertyValueFactory<Jeu,String>("nom_jeu"));
        ndc.setCellValueFactory(new PropertyValueFactory<Jeu,Integer>("niv_diff"));
       
        /*list.add(j);
        list.addAll(list0);
        table.setItems(list);*/
       
        typ11.setItems(list5);

        table11.getItems().clear();
        list0 = jcd.displayJeu();
        list.addAll(list0);
        table11.setItems(list);
    }

   
    @FXML
    public void Notificationget(){
        Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Adresse/Password invalide!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.show();
    }
   
   
    @FXML
    private void Jouer(ActionEvent event) throws IOException {
        GameFrame frame = new GameFrame();
    }

    @FXML
    public void Rechercher1() throws IOException{      
        try {
            if(tfid211.getText().isEmpty())
            {
                //JOptionPane.showMessageDialog(null, "Insert ID!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Insert ID!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.darkStyle();
        notificationBuilder.showError();
            }
            String requete = "SELECT * FROM jeux WHERE id='"+ tfid211.getText() +"'";
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                Jeu j = new Jeu();
                //Jeu t = new Jeu();
                j.setId(rs.getInt("id"));
                j.setId_client(rs.getInt("id_client"));
                j.setNom_cat(rs.getString("nom_cat"));
                j.setNom_jeu(rs.getString("nom_jeu"));
                j.setNiv_diff(rs.getInt("niv_diff"));
                //jeuList.add(p);
                list4.add(j);
            }
            table11.getItems().clear();
               
                table11.setItems(list4);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }

    @FXML
    private void Trier1()  throws IOException{
        List<Jeu> jeuList = new ArrayList<>();
        try {
            String requete = "SELECT * FROM jeux";
            if(typ11.getSelectionModel().isEmpty())
            {
                //JOptionPane.showMessageDialog(null, "Choose sort type!");
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Choose sort type!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            if(typ11.getSelectionModel().getSelectedItem().equals("By Cli name ascendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_cat ASC";
            }
            if(typ11.getSelectionModel().getSelectedItem().equals("By Cli name descendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_cat DESC";
            }
            if(typ11.getSelectionModel().getSelectedItem().equals("By Game's name ascendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_jeu ASC";
            }
            if(typ11.getSelectionModel().getSelectedItem().equals("By Game's name descendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY nom_jeu DESC";
            }
            if(typ11.getSelectionModel().getSelectedItem().equals("By Difficuly level ascendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY niv_diff ASC";
            }
            if(typ11.getSelectionModel().getSelectedItem().equals("By Difficuly level descendant"))
            {
                requete = "SELECT * FROM jeux ORDER BY niv_diff DESC";
            }
           
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                Jeu t = new Jeu();
                t.setId(rs.getInt("id"));
                t.setId_client(rs.getInt("id_client"));
                t.setNom_cat(rs.getString("nom_cat"));
                t.setNom_jeu(rs.getString("nom_jeu"));
                t.setNiv_diff(rs.getInt("niv_diff"));
                jeuList.add(t);
               
            }
            table11.getItems().clear();
                list.addAll(jeuList);                
                table11.setItems(list);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }

    @FXML
    void loadback(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GeneralMainPackage/GeneralFrontPage.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }
   
   
    @FXML
    void getScore(ActionEvent event) throws Exception {
        if((sfad.getText().isEmpty()) || (sfpwd.getText().isEmpty())){
            //JOptionPane.showMessageDialog(null, "Fill Adresse/Password!");
            Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Fill Adresse/Password!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
        }
        else{
            JavaMailUtil.sendMail(sfad.getText(),sfpwd.getText());
           
            Notifications notificationBuilder = Notifications.create()
                .title("Mail sent!")
                .text("Sent to Mail")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.darkStyle();
        notificationBuilder.show();
        }
       
    }
   
}

