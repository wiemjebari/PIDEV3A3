/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.entities;

/**
 *
 * @author ASUS
 */
public class Jeu {
    private int id;
    private int id_client;
    private String nom_cat;
    private String nom_jeu;
    private int niv_diff;

    public Jeu() {
    }

    public Jeu(int id, int id_client, String nom_cat, String nom_jeu, int niv_diff) {
        this.id = id;
        this.id_client = id_client;
        this.nom_cat = nom_cat;
        this.nom_jeu = nom_jeu;
        this.niv_diff = niv_diff;
    }

    public int getId() {
        return id;
    }
    
    public int getId_client() {
        return id_client;
    }

    public String getNom_cat() {
        return nom_cat;
    }

    public String getNom_jeu() {
        return nom_jeu;
    }

    public int getNiv_diff() {
        return niv_diff;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public void setId_client(int id_client) {
        this.id_client = id_client;
    }

    public void setNom_cat(String nom_cat) {
        this.nom_cat = nom_cat;
    }

    public void setNom_jeu(String nom_jeu) {
        this.nom_jeu = nom_jeu;
    }

    public void setNiv_diff(int niv_diff) {
        this.niv_diff = niv_diff;
    }

    @Override
    public String toString() {
        return "Jeu{" + "id_client=" + id_client + ", nom_cat=" + nom_cat + ", nom_jeu=" + nom_jeu + ", niv_diff=" + niv_diff + '}';
    }
    
    
    
}
