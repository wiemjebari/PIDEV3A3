/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.entities;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

/**
 *
 * @author ASUS
 */
public class User {
     
    private int id;
    private String nom;
    private String prenom;
    private String sexe;
    private String date_naiss;
    private String mail;
    private String adresse;//ou il vie
    private String role;
   
    private String password;
    private static int userconnected;
    

    public User() {
    }

    

    public User(int id, String resNom, String resPrenom, String resSexe, String resDate_naiss, String resMail, String resAdresse, String resRole, String resPassword) {
        this.id=id;
        this.nom=resNom;
        this.prenom=resPrenom;
        this.sexe=resSexe;
        this.date_naiss=resDate_naiss;
        this.mail=resMail;
        this.adresse=resAdresse;
        this.role=resRole;
    
        this.password=resPassword;
    }
    
    public java.sql.Date convertdate(LocalDate localDate){
        ZoneId defaultZoneId = ZoneId.systemDefault();
        
        java.sql.Date date = (java.sql.Date) java.sql.Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
        
        return date;
    }
    
    public User(String nom, String prenom, String sexe, String date_naiss, String mail, String adresse, String role, String password) {
        this.nom = nom;
        this.prenom = prenom;
        this.sexe = sexe;
        this.date_naiss = date_naiss;
        this.mail = mail;
        this.adresse = adresse;
        this.role = role;
       
        this.password = password;
    }

    

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getSexe() {
        return sexe;
    }

    public String getDate_naiss() {
        return date_naiss;
    }

    public String getMail() {
        return mail;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getRole() {
        return role;
    }

   
    public String getPassword() {
        return password;
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public void setDate_naiss(String date_naiss) {
        this.date_naiss = date_naiss;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setRole(String role) {
        this.role = role;
    }

   

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", sexe=" + sexe + ", date_naiss=" + date_naiss + ", mail=" + mail + ", adresse=" + adresse + ", role=" + role + ", password=" + password + '}';
    }

 

 
    
      public static int getUserconnected() {
        return userconnected;
    }
   

    public static void setUserconnected(int userconnected) {
        User.userconnected = userconnected;
    }
    
    
    
}
