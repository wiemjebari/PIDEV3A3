/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.interfaces;

import edu.db3a4.entities.User;
import java.util.List;

/**
 *
 * @author ASUS
 * @param <T>
 */
public interface IUser<T> {
    
    public void ajouterUser(T t);
    public void supprimerUser(T t);
    public void updateUser(T t);
    public List<T> displayUsers();
     public boolean verifAdmin(String username);
     public User AfficherUser(String username); 
     public Boolean Login(String username,String password);
     public List<User> getAllUser();
    
    
}
