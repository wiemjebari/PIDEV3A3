/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainController {

    @FXML
    private AnchorPane rootPane;
    
    @FXML
    private ImageView imgvi;

    @FXML
    private Button clientbtn;

    @FXML
    private Button jeubtn;
    
    @FXML
    private void loadSecond(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("Main-Menu.fxml"));
        rootPane.getChildren().setAll(pane);
        /*try{
          FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Main-Menu.fxml"));
    Parent root1 = (Parent) fxmlLoader.load();
    Stage stage = new Stage();
    stage.setScene(new Scene(root1));  
    stage.show();  
        } catch(Exception e){
            System.out.println("Can't load new window");
        }*/
        
    }
    
    @FXML
    private void loadThird(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("Main-Menu3.fxml"));
        rootPane.getChildren().setAll(pane);
        /*try{
          FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Main-Menu3.fxml"));
    Parent root2 = (Parent) fxmlLoader.load();
    Stage stage = new Stage();
    stage.setScene(new Scene(root2));  
    stage.show();  
        } catch(Exception e){
            System.out.println("Can't load new window");
        }*/
        
    }

    @FXML
    private void loadLogin(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Login.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }
    
    @FXML
    private void loadRegistration(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Registration.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }
    
}