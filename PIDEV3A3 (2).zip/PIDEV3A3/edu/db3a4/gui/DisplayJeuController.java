/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui;

import edu.db3a4.entities.Jeu;
import edu.db3a4.services.JeuCRUD;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class DisplayJeuController {

    @FXML
    private TextField tfIdc;
    @FXML
    private TextField tfnomc;
    @FXML
    private TextField tfnomj;
    @FXML
    private TextField tfniv;
    
    /**
     * Initializes the controller class.
     */
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    
    @FXML
    public void displayJeu(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB
           // String resIdc = tfIdc.getText();
           // String resNomc = tfnomc.getText();
           // String resNomj = tfnomj.getText();
            //String resNiv = tfniv.getText();
            //Jeu j = new Jeu(20,resNomc,resNomj,2);
            JeuCRUD jcd = new JeuCRUD();
            List<Jeu> list = jcd.displayJeu();
            Iterator<Jeu> i = list.iterator();
            ////New Code here
            
            while(i.hasNext()){
                System.out.println(i.next());
            }
            
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("JeuDetails.fxml"));
            Parent root = loader.load();
            JeuDetailsController uct = loader.getController();
          //  uct.setrNom(tfnomc.getText());
           // uct.setrPrenom(tfnomj.getText());
           // uct.setrNom(tfniv.getText());
            tfnomc.getScene().setRoot(root);
            
        } catch (IOException e) {
            System.out.println("Game not Displayed!");
        }
    }
    
}
