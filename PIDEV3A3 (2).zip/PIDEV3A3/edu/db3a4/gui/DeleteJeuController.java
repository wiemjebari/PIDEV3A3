/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui;

import edu.db3a4.entities.Jeu;
import edu.db3a4.services.JeuCRUD;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 *
 * @author HP
 */
public class DeleteJeuController {
    @FXML
    private TextField tfIdc;
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    @FXML
    public void DeleteJeu(int idclient) {
        Jeu j = new Jeu();
        idclient = Integer.parseInt(tfIdc.getText());
        j.setId_client(idclient);
        JeuCRUD jcd = new JeuCRUD();
        jcd.supprimerJeu(j);

    }
}
