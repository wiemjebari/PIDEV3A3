/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui;

import edu.db3a4.entities.Jeu;
import edu.db3a4.entities.User;
import edu.db3a4.services.JeuCRUD;
import edu.db3a4.services.UserCRUD;
import edu.db3a4.tools.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.JOptionPane;
import org.controlsfx.control.Notifications;

/**
 *
 * @author HP
 */
public class BackUserController implements Initializable{

   
    @FXML
    private AnchorPane rootPane8;

    @FXML
    private Button btn;

    @FXML
    private ImageView imgvi;

    @FXML
    private TableView<User> table1;

    @FXML
    private TableColumn<User, Integer> id;

    @FXML
    private TableColumn<User, String> nom;

    @FXML
    private TableColumn<User, String> pre;

    @FXML
    private TableColumn<User, String> se;

    @FXML
    private TableColumn<User, String> dat;

    @FXML
    private TableColumn<User, String> mai;

    @FXML
    private TableColumn<User, String> ad;

    @FXML
    private TableColumn<User, String> ro;

    @FXML
    private TableColumn<User, String> pwd;

    @FXML
    private TextField tfid1;
   
    @FXML
    private TextField tfnom1;

    @FXML
    private TextField tfprenom1;

    @FXML
    private ComboBox<String> tfsexe1;

    @FXML
    private DatePicker tfdaten1;

    @FXML
    private TextField tfmail1;

    @FXML
    private TextField tfad1;

    @FXML
    private ComboBox<String> tfrole1;

    @FXML
    private PasswordField tfpwd1;

    @FXML
    private Button btna1;

    @FXML
    private Button btnde1;

    @FXML
    private Button btnu1;

    @FXML
    private Button tfback;
   
    @FXML
    private Button btnt;

    @FXML
    private Button btnr;

    @FXML
    private TextField tfidr1;

    @FXML
    private ComboBox<String> tfidtri1;
   
    UserCRUD cd = new UserCRUD();
    List<User> list0 = cd.displayUsers();
    ObservableList<User> list = FXCollections.observableArrayList();
    ObservableList<String> list1 = FXCollections.observableArrayList("Homme","Femme");
    ObservableList<String> list2 = FXCollections.observableArrayList("Admin","Client");
    ObservableList<String> list6 =
            FXCollections.observableArrayList("By Cli name ascendant","By Cli name descendant",
    "By Cli surname ascendant","By Cli surname descendant");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
    User u;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
              ObservableList<User> list = FXCollections.observableArrayList();
        id.setCellValueFactory(new PropertyValueFactory<User,Integer>("id"));
        nom.setCellValueFactory(new PropertyValueFactory<User,String>("nom"));
        pre.setCellValueFactory(new PropertyValueFactory<User,String>("prenom"));
        se.setCellValueFactory(new PropertyValueFactory<User,String>("sexe"));
        dat.setCellValueFactory(new PropertyValueFactory<User,String>("date_naiss"));
        mai.setCellValueFactory(new PropertyValueFactory<User,String>("mail"));
        ad.setCellValueFactory(new PropertyValueFactory<User,String>("adresse"));
        ro.setCellValueFactory(new PropertyValueFactory<User,String>("role"));
        pwd.setCellValueFactory(new PropertyValueFactory<User,String>("password"));
        //System.err.println(list);
        //table1.setItems(list);
       
        //list.add(j);
        list.addAll(list0);
        table1.setItems(list);
       
       
        tfsexe1.setItems(list1);
       
        tfrole1.setItems(list2);  
       
        tfidtri1.setItems(list6);
    }
   
    @FXML
    public void Notificationget(){
        Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Adresse/Password invalide!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.show();
    }
   
    @FXML
    private void Delete2() throws IOException {
        ObservableList<User> selecteduser=table1.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selecteduser.get(0).getId());
        JeuCRUD jcd = new JeuCRUD();
        List<Jeu> list1 = jcd.displayJeu();
        int x = Integer.parseInt(y);
        for(int i=0;i<list1.size();i++){
            if(list1.get(i).getId_client() == x){
                jcd.supprimerJeu(list1.get(i));
            }
        }
        try {
            String requete = "DELETE FROM user where id_client=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
           
           
            pst.setString(1, y);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "User Supprimé!");
            System.out.println("User supprimée!");
            table1.getItems().clear();
            list0 = cd.displayUsers();
            list.addAll(list0);
            table1.setItems(list);
           
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @FXML
    private void Update2() throws IOException {
        ObservableList<User> selecteduser=table1.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selecteduser.get(0).getId());
        try {
            /*if(tfid.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Fill all info!");
            }
            list0 = cd.displayUsers();
            int resIdc1 = Integer.parseInt(y);
            u.setId(resIdc1);
            boolean test=false;
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == u.getId())
                    test=true;
            }
            if(test == false){
                JOptionPane.showMessageDialog(null, "Client dosen't exists!");
            }
            if(!((resIdc1 > 0) && (resIdc1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }*/
            boolean test=false;
            if(tfnom1.getText().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's Name!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's Name!!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.showError();
            }
            else if(tfprenom1.getText().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's Surname!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's Surname!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            /*else if(tfsexe.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid gender!");
            }*/
            else if(tfdaten1.getValue().toString().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's date!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's date!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
               
            }
            else if(tfmail1.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's mail ID!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's mail ID!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            else if(tfad1.getText().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's adresse");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's adresse!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            /*else if(tfrole.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid role!");
            }*/
            if(!tfad1.getText().contains("@")){
                //JOptionPane.showMessageDialog(null, "Not a valid addresse");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Not a valid addresse!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            if(tfrole1.getSelectionModel().getSelectedItem().equals("Admin")){
                if(!tfpwd1.getText().contains("01")){
                    //JOptionPane.showMessageDialog(null, "An administrator's password must contain '01'");
                    Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("An administrator's password must contain '01'")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
                    test=false;
                }
                else
                {
                    test=true;
                }
            }
            if(tfrole1.getSelectionModel().getSelectedItem().equals("Client")){
                if(!tfpwd1.getText().contains("05")){
                    //JOptionPane.showMessageDialog(null, "A client's password must contain '05'");
                    Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("A client's password must contain '05'")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
                    test=false;
                }
                else
                {
                    test=true;
                }
            }
            else if(tfpwd1.getText().isEmpty() || (test == false)) {
                //JOptionPane.showMessageDialog(null, "Fill Client's password!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's password!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            else{
            String requete = "UPDATE user SET nom=?, prenom=?, sexe=?, date_naissance=?, mail=?, adresse=?, role=?, password=? WHERE id_client=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);  
           
            pst.setString(1, tfnom1.getText());
            pst.setString(2, tfprenom1.getText());
            pst.setString(3, tfsexe1.getValue());
            pst.setString(4, tfdaten1.getValue().toString());
            pst.setString(5, tfmail1.getText());
            pst.setString(6, tfad1.getText());
            pst.setString(7, tfrole1.getValue());
            pst.setString(8, tfpwd1.getText());
            pst.setString(9, y);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "User modifiée!");
            System.out.println("User modifiée!");
            table1.getItems().clear();
            list0 = cd.displayUsers();
            list.addAll(list0);
            table1.setItems(list);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @FXML
    private void ajouterUser(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB
           /* if(tfid.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Fill all info!");
            }*/
            /*list0 = cd.displayUsers();
            int resIdc1 = Integer.parseInt(tfid.getText());
            u.setId(resIdc1);
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == u.getId())
                    JOptionPane.showMessageDialog(null, "Client already exists!");
            }
            if(!((resIdc1 > 0) && (resIdc1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }*/
            if(tfnom1.getText().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's Name!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's Name!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            if(tfprenom1.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's Surname!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's Surname!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
           
            if(tfdaten1.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Fill Client's date!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's date!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            if(tfmail1.getText().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's mail ID!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's mail ID!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            if(tfad1.getText().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's adresse");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's adresse!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            list0 = cd.displayUsers();
           
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getAdresse().equals(tfad1.getText()))
                    JOptionPane.showMessageDialog(null, "Address already exists!");              
            }
            /*if(tfrole.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid Role!");
            }*/
            if(tfpwd1.getText().isEmpty()) {
                //JOptionPane.showMessageDialog(null, "Fill Client's password!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Fill Client's password!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            else{
                DatePicker tmpdate = (DatePicker) tfdaten1;
            String date = (String) tmpdate.getValue().toString();
            date = date.substring(0, 4) + '/' + date.substring(5, 7) + '/' + date.substring(8);
            java.util.Date myDate = new java.util.Date(date);
            java.sql.Date sqldate = new java.sql.Date(myDate.getTime());
            //String resId = tfid.getText();
            String resNom = tfnom1.getText();
            String resPrenom = tfprenom1.getText();
            String resSexe = tfsexe1.getValue();
            String resDaten = tfdaten1.getValue().toString();
            String resMail = tfmail1.getText();
            String resAdresse = tfad1.getText();
            String resRole = tfrole1.getValue();
            String resPass = tfpwd1.getText();
            User u = new User(resNom,resPrenom,resSexe,resDaten,resMail,
                                                                    resAdresse,resRole,resPass);
           
                UserCRUD cd = new UserCRUD();
            cd.ajouterUser2(u);
            JOptionPane.showMessageDialog(null, "User ajouté");
            table1.getItems().clear();
            list0 = cd.displayUsers();
            list.addAll(list0);
            table1.setItems(list);
            }
           
           
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("backclient.fxml"));
            Parent root = loader.load();
            edu.db3a4.gui.UserDetailsController uct = loader.getController();
            uct.setrId(tfid1.getText());
            uct.setrNom(tfnom1.getText());
            uct.setrPrenom(tfprenom1.getText());
            uct.setRsexe(tfsexe1.getValue());
            uct.setRdate_naiss(tfdaten1.getValue());
            uct.setRmail(tfmail1.getText());
            uct.setRaddresse(tfad1.getText());
            uct.setRrole(tfrole1.getValue());
            uct.setRpassword(tfpwd1.getText());
            tfid1.getScene().setRoot(root);
           
        } catch (IOException e) {
            System.out.println("User not Added!");
        }
    }

    @FXML
    void loadback(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GeneralMainPackage/GeneralBackPage.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }

    @FXML
    private void pwdo() throws IOException {
        tfpwd1.setPromptText("New password here!");
        Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("New password here!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showInformation();
    }
   
    @FXML
    public void Rechercher2() throws IOException{      
        try {
            if(tfidr1.getText().isEmpty())
            {
                //JOptionPane.showMessageDialog(null, "Insert ID!");
                Notifications notificationBuilder = Notifications.create()
                .title("Info")
                .text("Insert ID!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
        notificationBuilder.showError();
            }
            String requete = "SELECT * FROM user WHERE id_client='"+ tfidr1.getText() +"'";
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfidr1.getText());
            ResultSet rs = pst.executeQuery(requete);
            table1.getItems().clear();
            while (rs.next()) {
                //Jeu t = new Jeu();
               
                User uu=new User();
                uu.setId(rs.getInt("id_client"));
                uu.setNom(rs.getString("nom"));
                uu.setPrenom(rs.getString("prenom"));
                uu.setSexe(rs.getString("sexe"));
                uu.setDate_naiss(rs.getString("date_naissance"));
                uu.setMail(rs.getString("mail"));
                uu.setAdresse(rs.getString("adresse"));
                uu.setRole(rs.getString("role"));
                uu.setPassword(rs.getString("password"));
                //jeuList.add(p);
                list.add(uu);
            }
            table1.getItems().clear();
               
                table1.setItems(list);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }
   
    @FXML
    private void Trier2()  throws IOException{
        List<User> userlist = new ArrayList<>();
        try {
            String requete = "SELECT * FROM user";
            if(tfidtri1.getSelectionModel().isEmpty())
            {
                //JOptionPane.showMessageDialog(null, "Choose sort type!");
                Notifications notificationBuilder = Notifications.create()
                .title("Login info")
                .text("Choose sort type!")
                .graphic(null)
                .hideAfter(Duration.seconds(5))
                .position(Pos.TOP_RIGHT)
                .onAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event){
                        System.out.println("Clicked on Notification");
                    }
            });
    notificationBuilder.darkStyle();
    notificationBuilder.showError();
            }
            if(tfidtri1.getSelectionModel().getSelectedItem().equals("By Cli name ascendant"))
            {
                requete = "SELECT * FROM user ORDER BY nom ASC";
            }
            if(tfidtri1.getSelectionModel().getSelectedItem().equals("By Cli name descendant"))
            {
                requete = "SELECT * FROM user ORDER BY nom DESC";
            }
            if(tfidtri1.getSelectionModel().getSelectedItem().equals("By Cli surname ascendant"))
            {
                requete = "SELECT * FROM user ORDER BY prenom ASC";
            }
            if(tfidtri1.getSelectionModel().getSelectedItem().equals("By Cli surname descendant"))
            {
                requete = "SELECT * FROM user ORDER BY prenom DESC";
            }
           
           
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                User t = new User();
                t.setId(rs.getInt("id_client"));
                t.setNom(rs.getString("nom"));
                t.setPrenom(rs.getString("prenom"));
                t.setSexe(rs.getString("sexe"));
                t.setDate_naiss(rs.getString("date_naissance"));
                t.setMail(rs.getString("mail"));
                t.setAdresse(rs.getString("adresse"));
                t.setRole(rs.getString("role"));
                t.setPassword(rs.getString("password"));
                userlist.add(t);
               
            }
            table1.getItems().clear();
                list.addAll(userlist);                
                table1.setItems(list);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }
   
}