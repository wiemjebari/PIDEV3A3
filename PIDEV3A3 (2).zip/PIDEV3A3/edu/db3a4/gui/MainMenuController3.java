/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui;



import edu.db3a4.entities.Jeu;
import edu.db3a4.entities.User;
import edu.db3a4.services.JeuCRUD;
import edu.db3a4.services.UserCRUD;
import edu.db3a4.tools.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class MainMenuController3 implements Initializable {

    @FXML
    private Button btn;
    
    @FXML
    private AnchorPane rootpane;
    
    @FXML
    private AnchorPane rootPane2;
    
    @FXML
    private ImageView imgvi;

    @FXML
    private TableView<User> table;

    @FXML
    private TableColumn<User, Integer> id;

    @FXML
    private TableColumn<User, String> nom;

    @FXML
    private TableColumn<User, String> pre;

    @FXML
    private TableColumn<User, String> se;

    @FXML
    private TableColumn<User, Date> dat;

    @FXML
    private TableColumn<User, String> mai;

    @FXML
    private TableColumn<User, String> ad;

    @FXML
    private TableColumn<User, String> ro;

    @FXML
    private TableColumn<User, String> pwd;

    @FXML
    private TextField tfid;

    @FXML
    private TextField tfnom;

    @FXML
    private TextField tfprenom;

    @FXML
    private ComboBox<String> tfsexe;
    
    @FXML
    private DatePicker tfdaten;

    @FXML
    private TextField tfmail;

    @FXML
    private TextField tfad;

    @FXML
    private ComboBox<String> tfrole;

    @FXML
    private PasswordField tfpwd;
    

    @FXML
    private Button btna;

    @FXML
    private Button btnu;

    @FXML
    private Button btnde;

    @FXML
    private Button btndi;

    @FXML
    private TextField tfid2;
    
    @FXML
    private ComboBox<String> combo1;
    
    @FXML
    private ComboBox<String> combo2;
    
    @FXML
    private Label label;
    
    @FXML
    private Button btnt;

    @FXML
    private Button btnr;

    @FXML
    private TextField tfidr;
    
    @FXML
    private ComboBox<String> tfidtri;
    
    
    
    UserCRUD cd = new UserCRUD();
    List<User> list0 = cd.displayUsers();
    ObservableList<User> list = FXCollections.observableArrayList();
    ObservableList<String> list1 = FXCollections.observableArrayList("Homme","Femme");
    ObservableList<String> list2 = FXCollections.observableArrayList("Admin","Client");
    ObservableList<String> list6 =
            FXCollections.observableArrayList("By Cli name ascendant","By Cli name descendant",
    "By Cli surname ascendant","By Cli surname descendant");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
    User u;

    /*public MainMenuController3() throws ParseException {
        this.u = new User("Aile","Checkers","F",sdf.parse("1946-04-01"),"night.zex@esprit.tn","chaos","Utilisateur",
                "6548");
    }*/
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        id.setCellValueFactory(new PropertyValueFactory<User,Integer>("id"));
        nom.setCellValueFactory(new PropertyValueFactory<User,String>("nom"));
        pre.setCellValueFactory(new PropertyValueFactory<User,String>("prenom"));
        se.setCellValueFactory(new PropertyValueFactory<User,String>("sexe"));
        dat.setCellValueFactory(new PropertyValueFactory<User,Date>("date_naissance"));
        mai.setCellValueFactory(new PropertyValueFactory<User,String>("mail"));
        ad.setCellValueFactory(new PropertyValueFactory<User,String>("adresse"));
        ro.setCellValueFactory(new PropertyValueFactory<User,String>("role"));
        pwd.setCellValueFactory(new PropertyValueFactory<User,String>("password"));
        
        //list.add(j);
        list.addAll(list0);
        table.setItems(list);
        
        
        tfsexe.setItems(list1);
        
        tfrole.setItems(list2);
        
        tfidtri.setItems(list6);
    }
    
    @FXML
    void Select(ActionEvent event) {
        
        String s = combo1.getSelectionModel().getSelectedItem().toString();
        label.setText(s);
    }
    
    @FXML
    private void loadback(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
        rootPane2.getChildren().setAll(pane);
    }
    
    @FXML
    private void DisplayUser(ActionEvent event) throws IOException {
        try{   
            UserCRUD jcd = new UserCRUD();
            List<User> list0 = jcd.displayUsers();
            Iterator<User> i = list0.iterator();
            ObservableList<User> list = FXCollections.observableArrayList();
            list.addAll(list0);
            table.setItems(list);
            while(i.hasNext()){                
                System.out.println(i.next());
            }
        } catch(Exception e){
            System.out.println("Can't load new window");
        }
    }
 
    public Date setdate(LocalDate d){
        ZoneId defaultZoneId = ZoneId.systemDefault();
        Date date = Date.from(d.atStartOfDay(defaultZoneId).toInstant());
        return date;
    }
    
    @FXML
    private void ajouterUser(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB
           /* if(tfid.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Fill all info!");
            }*/
            /*list0 = cd.displayUsers();
            int resIdc1 = Integer.parseInt(tfid.getText());
            u.setId(resIdc1);
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == u.getId())
                    JOptionPane.showMessageDialog(null, "Client already exists!");
            }
            if(!((resIdc1 > 0) && (resIdc1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }*/
            if(tfnom.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's Name!");
            }
            if(tfprenom.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's Surname!");
            }
            
            if(tfdaten.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Fill Client's date!");
            }
            if(tfmail.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's mail ID!");
            }
            if(tfad.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's adresse");
            }
            list0 = cd.displayUsers();
            
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getAdresse().equals(tfad.getText()))
                    JOptionPane.showMessageDialog(null, "Address already exists!");
            }
            /*if(tfrole.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid Role!");
            }*/
            if(tfpwd.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's password!");
            }
            else{
                DatePicker tmpdate = (DatePicker) tfdaten;
            String date = (String) tmpdate.getValue().toString();
            date = date.substring(0, 4) + '/' + date.substring(5, 7) + '/' + date.substring(8);
            java.util.Date myDate = new java.util.Date(date);
            java.sql.Date sqldate = new java.sql.Date(myDate.getTime());
            //String resId = tfid.getText();
            String resNom = tfnom.getText();
            String resPrenom = tfprenom.getText();
            String resSexe = tfsexe.getValue();
            String resDaten = tfdaten.getValue().toString();
            String resMail = tfmail.getText();
            String resAdresse = tfad.getText();
            String resRole = tfrole.getValue();
            String resPass = tfpwd.getText();
          //  User u = new User(resNom,resPrenom,resSexe,sqldate,resMail,
                                                                 //   resAdresse,resRole,resPass);
            
                UserCRUD cd = new UserCRUD();
            cd.ajouterUser(u);
            JOptionPane.showMessageDialog(null, "User ajouté");
            table.getItems().clear();
            list0 = cd.displayUsers();
            list.addAll(list0);
            table.setItems(list);
            }
            
            
            //REDIRECTION
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("Main-Menu3.fxml"));
            Parent root = loader.load();
            edu.db3a4.gui.UserDetailsController uct = loader.getController();
            uct.setrId(tfid.getText());
            uct.setrNom(tfnom.getText());
            uct.setrPrenom(tfprenom.getText());
            uct.setRsexe(tfsexe.getValue());
            uct.setRdate_naiss(tfdaten.getValue());
            uct.setRmail(tfmail.getText());
            uct.setRaddresse(tfad.getText());
            uct.setRrole(tfrole.getValue());
            uct.setRpassword(tfpwd.getText());
            tfid.getScene().setRoot(root);
            
        } catch (IOException e) {
            System.out.println("User not Added!");
        }
    }
    
    @FXML
    private void pwdo() throws IOException {
        tfpwd.setPromptText("New password here!");
    }
    
    @FXML
    private void Display2() throws IOException { 
           
        table.getItems().clear();
        list0 = cd.displayUsers();
        list.addAll(list0);
        table.setItems(list);
        
    }
    
    @FXML
    private void Delete2() throws IOException {
        ObservableList<User> selecteduser=table.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selecteduser.get(0).getId());
        JeuCRUD jcd = new JeuCRUD();
        List<Jeu> list1 = jcd.displayJeu();
        int x = Integer.parseInt(y);
        for(int i=0;i<list1.size();i++){
            if(list1.get(i).getId_client() == x){
                jcd.supprimerJeu(list1.get(i));
            }
        }
        try {
            String requete = "DELETE FROM user where id_client=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            
            
            pst.setString(1, y);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "User Supprimé!");
            System.out.println("User supprimée!");
            table.getItems().clear();
            list0 = cd.displayUsers();
            list.addAll(list0);
            table.setItems(list);
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    @FXML
    private void Update2() throws IOException {
        ObservableList<User> selecteduser=table.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selecteduser.get(0).getId());
        try {
            /*if(tfid.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Fill all info!");
            }
            list0 = cd.displayUsers();
            int resIdc1 = Integer.parseInt(y);
            u.setId(resIdc1);
            boolean test=false;
            for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == u.getId())
                    test=true;
            }
            if(test == false){
                JOptionPane.showMessageDialog(null, "Client dosen't exists!");
            }
            if(!((resIdc1 > 0) && (resIdc1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }*/
            if(tfnom.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's Name!");
            }
            else if(tfprenom.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's Surname!");
            }
            /*else if(tfsexe.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid gender!");
            }*/
            else if(tfdaten.getValue().toString().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's date!");
            }
            else if(tfmail.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's mail ID!");
            }
            else if(tfad.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's adresse");
            }
            /*else if(tfrole.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid role!");
            }*/
            else if(tfpwd.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's password!");
            }
            else{
            String requete = "UPDATE user SET nom=?, prenom=?, sexe=?, date_naissance=?, mail=?, adresse=?, role=?, password=? WHERE id_client=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);            
            pst.setString(1, tfnom.getText());
            pst.setString(2, tfprenom.getText());
            pst.setString(3, tfsexe.getValue());
            pst.setString(4, tfdaten.getValue().toString());
            pst.setString(5, tfmail.getText());
            pst.setString(6, tfad.getText());
            pst.setString(7, tfrole.getValue());
            pst.setString(8, tfpwd.getText());
            pst.setString(9, y);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "User modifiée!");
            System.out.println("User modifiée!");
            table.getItems().clear();
            list0 = cd.displayUsers();
            list.addAll(list0);
            table.setItems(list);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    @FXML
    public void Rechercher2() throws IOException{      
        try {
            String requete = "SELECT * FROM user WHERE id_client="+ tfidr.getText() +"";
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                //Jeu t = new Jeu();
                u.setId(rs.getInt("id_client"));
                u.setNom(rs.getString("nom"));
                u.setPrenom(rs.getString("prenom"));
                u.setSexe(rs.getString("sexe"));
             //   u.setDate_naiss(rs.getDate("date_naissance"));
                u.setMail(rs.getString("mail"));
                u.setAdresse(rs.getString("adresse"));
                u.setRole(rs.getString("role"));
                u.setPassword(rs.getString("password"));
                //jeuList.add(p);
                
            }
            table.getItems().clear();
                list.add(u);
                table.setItems(list);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }
    
    
    @FXML
    private void Trier2()  throws IOException{ 
        List<User> userlist = new ArrayList<>();
        try {
            String requete = "SELECT * FROM user";
            if(tfidtri.getSelectionModel().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Choose sort type!");
            }
            if(tfidtri.getSelectionModel().getSelectedItem().equals("By Cli name ascendant"))
            {
                requete = "SELECT * FROM user ORDER BY nom ASC";
            }
            if(tfidtri.getSelectionModel().getSelectedItem().equals("By Cli name descendant"))
            {
                requete = "SELECT * FROM user ORDER BY nom DESC";
            }
            if(tfidtri.getSelectionModel().getSelectedItem().equals("By Cli surname ascendant"))
            {
                requete = "SELECT * FROM user ORDER BY prenom ASC";
            }
            if(tfidtri.getSelectionModel().getSelectedItem().equals("By Cli surname descendant"))
            {
                requete = "SELECT * FROM user ORDER BY prenom DESC";
            }
            
            
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                User t = new User();
                t.setId(rs.getInt("id_client"));
                t.setNom(rs.getString("nom"));
                t.setPrenom(rs.getString("prenom"));
                t.setSexe(rs.getString("sexe"));
          //      t.setDate_naiss(rs.getDate("date_naissance"));
                t.setMail(rs.getString("mail"));
                t.setAdresse(rs.getString("adresse"));
                t.setRole(rs.getString("role"));
                t.setPassword(rs.getString("password"));
                userlist.add(t);
                
            }
            table.getItems().clear();
                list.addAll(userlist);                
                table.setItems(list);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
    }

}
