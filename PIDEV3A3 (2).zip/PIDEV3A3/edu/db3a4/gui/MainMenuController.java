/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.gui;

import edu.db3a4.entities.Jeu;
import edu.db3a4.entities.User;
import edu.db3a4.services.JeuCRUD;
import edu.db3a4.services.UserCRUD;
import edu.db3a4.tools.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import mini.game.proto.GameFrame;

/**
 *
 * @author ASUS
 */
public class MainMenuController implements Initializable {

    @FXML
    private AnchorPane rootPane;
    @FXML
    private AnchorPane rootPane1;
    @FXML
    private Button tfbtn;
    @FXML
    private Button tfbtnm;
    @FXML
    private Button tfbtnd;

    @FXML
    private ImageView imgvi;

    @FXML
    private TableView<Jeu> table;

    @FXML
    private TableColumn<Jeu, Integer> idd;

    @FXML
    private TableColumn<Jeu, Integer> idcc;

    @FXML
    private TableColumn<Jeu, String> ncc;

    @FXML
    private TableColumn<Jeu, String> njc;

    @FXML
    private TableColumn<Jeu, Integer> ndc;

    @FXML
    private TextField tfid;

    @FXML
    private TextField tfidc;

    @FXML
    private ComboBox<Integer> tfidc1;

    @FXML
    private ComboBox<String> tfnomc;

    @FXML
    private ComboBox<String> tfnomj;

    @FXML
    private TextField tfniv;

    @FXML
    private TextField tfidc2;

    @FXML
    private TextField tfid2;

    @FXML
    private Button btna;

    @FXML
    private Button btnu;

    @FXML
    private Button btnde;

    @FXML
    private Button btnfi;

    @FXML
    private Button btndi;

    @FXML
    private ComboBox<Integer> combo;

    @FXML
    private Label label;

    @FXML
    private Button btnso;

    @FXML
    private ComboBox<String> typ;

    @FXML
    private Button tfback;

    JeuCRUD jcd = new JeuCRUD();
    List<Jeu> list0;
    ObservableList<Jeu> list = FXCollections.observableArrayList();
    ObservableList<Jeu> list4 = FXCollections.observableArrayList();
    ObservableList<String> list5
            = FXCollections.observableArrayList("By Cli name ascendant", "By Cli name descendant",
                    "By Game's name ascendant", "By Game's name descendant",
                    "By Difficuly level ascendant", "By Difficuly level descendant");
    Jeu j = new Jeu(1, 3, "Aile", "Checkers", 1);
    UserCRUD cd = new UserCRUD();
    List<User> listc = cd.displayUsers();

    /*new Jeu(4,"Ashe","saints",3),
                new Jeu(5,"prometheus","pong",2),
                new Jeu(6,"gery","yoh",1)*/
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        idd.setCellValueFactory(new PropertyValueFactory<Jeu, Integer>("id"));
        idcc.setCellValueFactory(new PropertyValueFactory<Jeu, Integer>("id_client"));
        ncc.setCellValueFactory(new PropertyValueFactory<Jeu, String>("nom_cat"));
        njc.setCellValueFactory(new PropertyValueFactory<Jeu, String>("nom_jeu"));
        ndc.setCellValueFactory(new PropertyValueFactory<Jeu, Integer>("niv_diff"));

        /*list.add(j);
        list.addAll(list0);
        table.setItems(list);*/
        ObservableList<Integer> list1 = FXCollections.observableArrayList(1, 2, 3);
        combo.setItems(list1);
        ObservableList<Integer> list2 = FXCollections.observableArrayList();
        tfidc1.setItems(list2);
        typ.setItems(list5);

        ObservableList<String> list6
                = FXCollections.observableArrayList("Adventure", "Sports", "Yoga");
        ObservableList<String> list7
                = FXCollections.observableArrayList("Ping-Pong", "Snake", "Green-Hill");
        tfnomc.setItems(list6);
        tfnomj.setItems(list7);

        for (int i = 0; i < listc.size(); i++) {
            list2.add(listc.get(i).getId());
        }
        table.getItems().clear();
        list0 = jcd.displayJeu();
        list.addAll(list0);
        table.setItems(list);
    }

    @FXML
    private int getlastID() {
        JeuCRUD jcd = new JeuCRUD();
        List<Jeu> listj = jcd.displayJeu();
        return listj.size() + 1;
    }

    @FXML
    private void Select(ActionEvent event) {

        String s = combo.getSelectionModel().getSelectedItem().toString();
        label.setText(s);
    }

    @FXML
    private void loadSecond(ActionEvent event) throws IOException {
        //AnchorPane pane = FXMLLoader.load(getClass().getResource("AddUser.fxml"));
        //rootPane.getChildren().setAll(pane);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AddUser.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load new window");
        }

    }

    @FXML
    private void loadupdate(ActionEvent event) throws IOException {
        //AnchorPane pane = FXMLLoader.load(getClass().getResource("AddUser.fxml"));
        //rootPane.getChildren().setAll(pane);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("UpdateUser.fxml"));
            Parent root2 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root2));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load new window");
        }

    }

    @FXML
    private void Jouer(ActionEvent event) throws IOException {
        GameFrame frame = new GameFrame();
    }

    @FXML
    private void loadSecondJ(ActionEvent event) throws IOException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AddJeu.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load new window");
        }
    }

    @FXML
    private void loadback(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
        rootPane1.getChildren().setAll(pane);
    }

    @FXML
    private void DisplayJeu(ActionEvent event) throws IOException {
        try {
            JeuCRUD jcd = new JeuCRUD();
            List<Jeu> list0 = jcd.displayJeu();
            Iterator<Jeu> i = list0.iterator();
            ObservableList<Jeu> list = FXCollections.observableArrayList();
            list.addAll(list0);
            table.setItems(list);
            while (i.hasNext()) {
                System.out.println(i.next());
            }
        } catch (Exception e) {
            System.out.println("Can't load new window");
        }
    }

    @FXML
    public void Rechercher1() throws IOException {
        try {
            String requete = "SELECT * FROM jeux WHERE id=" + tfid2.getText() + "";
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                //Jeu t = new Jeu();
                j.setId(rs.getInt("id"));
                j.setId_client(rs.getInt("id_client"));
                j.setNom_cat(rs.getString("nom_cat"));
                j.setNom_jeu(rs.getString("nom_jeu"));
                j.setNiv_diff(rs.getInt("niv_diff"));
                //jeuList.add(p);

            }
            table.getItems().clear();
            list4.add(j);
            table.setItems(list4);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @FXML
    private void Trier1() throws IOException {
        List<Jeu> jeuList = new ArrayList<>();
        try {
            String requete = "SELECT * FROM jeux";
            if (typ.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Choose sort type!");
            }
            if (typ.getSelectionModel().getSelectedItem().equals("By Cli name ascendant")) {
                requete = "SELECT * FROM jeux ORDER BY nom_cat ASC";
            }
            if (typ.getSelectionModel().getSelectedItem().equals("By Cli name descendant")) {
                requete = "SELECT * FROM jeux ORDER BY nom_cat DESC";
            }
            if (typ.getSelectionModel().getSelectedItem().equals("By Game's name ascendant")) {
                requete = "SELECT * FROM jeux ORDER BY nom_jeu ASC";
            }
            if (typ.getSelectionModel().getSelectedItem().equals("By Game's name descendant")) {
                requete = "SELECT * FROM jeux ORDER BY nom_jeu DESC";
            }
            if (typ.getSelectionModel().getSelectedItem().equals("By Difficuly level ascendant")) {
                requete = "SELECT * FROM jeux ORDER BY niv_diff ASC";
            }
            if (typ.getSelectionModel().getSelectedItem().equals("By Difficuly level descendant")) {
                requete = "SELECT * FROM jeux ORDER BY niv_diff DESC";
            }

            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            //pst.setString(1, tfid2.getText());
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                Jeu t = new Jeu();
                t.setId(rs.getInt("id"));
                t.setId_client(rs.getInt("id_client"));
                t.setNom_cat(rs.getString("nom_cat"));
                t.setNom_jeu(rs.getString("nom_jeu"));
                t.setNiv_diff(rs.getInt("niv_diff"));
                jeuList.add(t);

            }
            table.getItems().clear();
            list.addAll(jeuList);
            table.setItems(list);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @FXML
    private void deletejeu(ActionEvent event) throws IOException {
        try {
            Parent root1 = FXMLLoader.load(getClass().getResource("DeleteJeu.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();

        } catch (Exception e) {
            System.out.println("Can't load new window");
        }
    }

    @FXML
    private void ajouterJeu(ActionEvent event) {
        try {
            //// SAVE PERSON IN DB 
            /*if(tfid.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill ID!");
            }*/
            if (tfidc1.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill ID_Client!");
            }
            list0 = jcd.displayJeu();
            //int resId1 = Integer.parseInt(tfid.getText());
            int resId1 = getlastID();
            j.setId(resId1);
            /*for(int i=0;i<list0.size();i++){
                if(list0.get(i).getId() == j.getId())
                    JOptionPane.showMessageDialog(null, "Game already exists!");
            }*/
 /*if(list0.contains(tfid.getText())){
                JOptionPane.showMessageDialog(null, "Game already exists!");
            }*/
 /*if(!((resId1 > 0) && (resId1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }*/
            if (tfnomc.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's name!");
            } else if (tfnomj.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Game's name!");
            } /*else if(tfniv.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill Difficuty level!");    
            }*/ else if (combo.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Difficuty level!");
            } else {
                String resIdc = tfidc1.getSelectionModel().getSelectedItem().toString();
                String resNomc = tfnomc.getSelectionModel().getSelectedItem();
                String resNomj = tfnomj.getSelectionModel().getSelectedItem();
                //String resNiv = tfniv.getText();
                //int resNiv1 = Integer.parseInt(resNiv);
                int resIdc1 = Integer.parseInt(tfidc1.getSelectionModel().getSelectedItem().toString());
                int resNiv1 = Integer.parseInt(combo.getSelectionModel().getSelectedItem().toString());

                Jeu j = new Jeu(resId1, resIdc1, resNomc, resNomj, resNiv1);
                JeuCRUD jcd = new JeuCRUD();
                jcd.ajouterJeu(j);
                JOptionPane.showMessageDialog(null, "Jeu ajouté");
                table.getItems().clear();
                list0 = jcd.displayJeu();
                list.addAll(list0);
                table.setItems(list);

                //REDIRECTION
                FXMLLoader loader = new FXMLLoader(getClass()
                        .getResource("Main-Menu.fxml"));
                Parent root = loader.load();
                JeuDetailsController uct = loader.getController();
                //uct.setrId(tfidc1.getSelectionModel().getSelectedItem().toString());
                uct.setrNomc(tfnomc.getSelectionModel().getSelectedItem());
                uct.setrNomj(tfnomj.getSelectionModel().getSelectedItem());
                //uct.setrNom(tfniv.getText());
                uct.setrNiv(combo.getSelectionModel().getSelectedItem());
                tfid.getScene().setRoot(root);
            }

        } catch (IOException e) {
            System.out.println("Game not Added!");
        }
    }

    @FXML
    private void Display1() throws IOException {

        table.getItems().clear();
        list0 = jcd.displayJeu();
        list.addAll(list0);
        table.setItems(list);

    }

    @FXML
    private ObservableList<Jeu> gettablevalue(ObservableList<Jeu> selectedgame) {
        selectedgame = table.getSelectionModel().getSelectedItems();
        return selectedgame;
    }

    @FXML
    private void Delete1() throws IOException {
        ObservableList<Jeu> selectedgame = table.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selectedgame.get(0).getId());
        try {
            String requete = "DELETE FROM jeux where id=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            if (table.getSelectionModel().getSelectedItem().toString() == null) {
                JOptionPane.showMessageDialog(null, "Select Game!");
            }
            pst.setString(1, y);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Jeu Supprimé");
            System.out.println("Jeu supprimée!");
            table.getItems().clear();
            list0 = jcd.displayJeu();
            list.addAll(list0);
            table.setItems(list);
            for (int i = 0; i < table.getItems().size(); i++) {
                table.getSelectionModel().getSelectedItems().get(i).setId(
                        table.getSelectionModel().getSelectedIndex());
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @FXML
    private void Update1() throws IOException {
        ObservableList<Jeu> selectedgame = table.getSelectionModel().getSelectedItems();
        String y = String.valueOf(selectedgame.get(0).getId());
        try {
            /*if(tfid.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill ID!");
            } */
            if (tfidc1.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill ID_Client!");
            }
            list0 = jcd.displayJeu();
            int resId1 = Integer.parseInt(y);//(tfid.getText());
            j.setId(resId1);
            boolean test = false;
            for (int i = 0; i < list0.size(); i++) {
                if (list0.get(i).getId() == j.getId()) {
                    test = true;
                }
            }
            if (test == false) {
                JOptionPane.showMessageDialog(null, "Game dosen't exists!");
            }
            if (!((resId1 > 0) && (resId1 < 500))) {
                JOptionPane.showMessageDialog(null, "Invalid ID!");
            }
            if (tfnomc.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Client's name!");
            } else if (tfnomj.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Game's name!");
            } /*else if(tfniv.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Fill Difficuty level!");    
            }*/ else if (combo.getSelectionModel().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Fill Difficuty level!");
            } else {
                String requete = "UPDATE jeux SET nom_cat=?, nom_jeu=?, niv_diff=? WHERE id=?";
                PreparedStatement pst = MyConnection.getInstance().getCnx()
                        .prepareStatement(requete);
                pst.setString(1, tfnomc.getSelectionModel().getSelectedItem().toString());
                pst.setString(2, tfnomj.getSelectionModel().getSelectedItem().toString());
                //pst.setString(3, tfniv.getText());
                pst.setString(3, combo.getSelectionModel().getSelectedItem().toString());
                pst.setString(4, y);//tfid.getText());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Jeu modifiée!");
                System.out.println("Jeu modifiée!");
                table.getItems().clear();
                list0 = jcd.displayJeu();
                list.addAll(list0);
                table.setItems(list);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
