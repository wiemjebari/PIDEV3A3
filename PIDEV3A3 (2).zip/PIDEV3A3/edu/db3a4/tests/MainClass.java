/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.db3a4.tests;

import edu.db3a4.entities.User;
import edu.db3a4.services.UserCRUD;
import edu.db3a4.tools.MyConnection;

/**
 *
 * @author House
 */
public class MainClass {
    
    public static void main(String[] args) {
        MyConnection mc = MyConnection.getInstance();
        MyConnection mc2 = MyConnection.getInstance();
        System.out.println(mc.hashCode()+"--"+mc2.hashCode());
        User u = new User(0, "Zex", "n", "Masculin","23/04/-15000","zex@gmail.com","nagazaki"
                ,"pro","654");
        UserCRUD ucd = new UserCRUD();
        ucd.ajouterUser(u);
       // System.out.println(pcd.displayPersons());
    }
}
