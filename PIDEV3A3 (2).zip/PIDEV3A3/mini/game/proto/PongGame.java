/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
Don't forger about git -^-
 */
package mini.game.proto;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author ASUS
 */
public class PongGame {

    public PongGame() {
        GameFrame f1 = new GameFrame();
        
        f1.addWindowListener(new WindowAdapter() {
        
            @Override
            public void windowClosing(WindowEvent e){
                System.exit(0);
            }
        
        });
        
    }
    
    
    
    public static void main(String[] args) {
        
        GameFrame frame = new GameFrame();
        
    }
}
