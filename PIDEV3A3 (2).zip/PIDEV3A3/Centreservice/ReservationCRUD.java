/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Centreservice;

import CentreInterface.IRes;
import entities.Reservation_Centre;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import tools.MyConnection;

/**
 *
 * @author asmab
 */
public class ReservationCRUD implements IRes<Reservation_Centre>{

    @Override
    public void ajouterReservation(Reservation_Centre t) {
         try {
            //creation de la requete de l ajout
            String requete= "INSERT INTO reservation_centre(nom_centre,date,services,prix_service)"
                    + "VALUES (?,?,?,?)";
            //preparedstatement requete dynamique
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            
            pst.setString(1, t.getNom_centre());
            
             DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
           LocalDate l = LocalDate.parse(t.getDate(), formatter);
              pst.setString(2, l.toString());
               pst.setString(3, t.getServices());
               pst.setInt(4, t.getPrix());
              
              System.err.println(pst);
              
            pst.executeUpdate();
            System.out.println("Reservation inserrée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimerReservation(Reservation_Centre t) {
        String requete = "DELETE FROM reservation_centre WHERE id_reservation=?";
         try {
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
           pst.setInt(1, t.getId_reservation());
            pst.executeUpdate();
            System.out.println("Reservation supprimée");
            } catch (SQLException ex) {
            Logger.getLogger(CentreCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void updateReservation(Reservation_Centre t) {
        try {
            String requete = "UPDATE reservation_centre SET date=? WHERE id_reservation=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setString(1, t.getDate());
            
            pst.executeUpdate();
            System.out.println("Reservation modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List<Reservation_Centre> displayReservation() {
              List<Reservation_Centre> ResList = new ArrayList<>();
        try {
            String requete = "SELECT * FROM reservation_centre";
            Statement st = MyConnection.getInstance().getCnx()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
               Reservation_Centre p = new Reservation_Centre();
               
                p.setNom_centre(rs.getString("nom_centre"));//id user
                p.setServices(rs.getString("id_service"));
                 p.setDate(rs.getString("date"));
                  p.setPrix(rs.getInt("prix_service"));
                  
                    
                 ResList.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return ResList;
    }
    
}
