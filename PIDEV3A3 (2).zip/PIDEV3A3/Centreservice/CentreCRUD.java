/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Centreservice;

import CentreInterface.ICentre;
import entities.Centre;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import tools.MyConnection;

public class CentreCRUD implements ICentre<Centre>{
public ObservableList<Centre> liste = FXCollections.observableArrayList();
    @Override
    public void ajouterCentre(Centre t) {
        try {
            //creation de la requete d insertion des donnees
            String requete = "INSERT INTO centre (id,nom_centre,adresse,services,num_tel,e_mail)"
                    + "VALUES ("+null+",'"+t.getNom_centre()+"','"+t.getAdresse()+"','"+t.getServices()+"','"
                    + ""+t.getNum_tel()+"','"+t.getE_mail()+"')";
            System.err.println(requete);
            //creation du staytement requete statique simple
            Statement st = MyConnection.getInstance().getCnx()
                    .createStatement();
            st.executeUpdate(requete);
            System.out.println("Centre ajouté");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    
    }
    
    public void ajouterCentre2(Centre t){
        try {
            //creation de la requete de l ajout
            String requete= "INSERT INTO centre(nom,adresse,services,num_tel,e_mail)"
                    + "VALUES (?,?)";
            //preparedstatement requete dynamique
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            pst.setString(1, t.getNom_centre());
            pst.setString(2, t.getAdresse());
             pst.setString(3, t.getServices());
              pst.setInt(4, t.getNum_tel());
               pst.setString(5, t.getE_mail());
            pst.executeUpdate();
            System.out.println("Centre inseré");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimerCentre(Centre t) {
        String requete = "DELETE FROM centre WHERE id=?";
        
          
        try {
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
        pst.setInt(1, t.getId());
            pst.executeUpdate();
            System.out.println("Centre supprimée");
          
          // int rowsDeleted = pst.executeUpdate();
           //if (rowsDeleted > 0) {
    //System.out.println("A center was deleted successfully!");
           
        } catch (SQLException ex) {
            Logger.getLogger(CentreCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @Override
    public void updateCentre(Centre t,String adr) {
        try {
            String requete = "UPDATE centre SET adresse=? WHERE id=?";
            PreparedStatement pst = MyConnection.getInstance().getCnx()
                    .prepareStatement(requete);
            System.out.println(adr);
            System.out.println(t.getId());
              pst.setString(1, adr);
               pst.setInt(2,t.getId());
            System.out.println(pst);
            pst.executeUpdate();
            System.out.println("Centre modifié");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List<Centre> displayCentre() {
                List<Centre> CentreList = new ArrayList<>();
        try {
            String requete = "SELECT * FROM centre";
            Statement st = MyConnection.getInstance().getCnx()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
                Centre p = new Centre();
              
                p.setNom_centre(rs.getString(2));
                p.setAdresse(rs.getString("Adresse"));
                 p.setServices(rs.getString("Service"));
                  p.setNum_tel(rs.getInt("Num_tel"));
                   p.setE_mail(rs.getString("E_mail"));
                    
                CentreList.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return CentreList;
    }
    
    
    }

    
/**
 *
 * @author asmab
 */

