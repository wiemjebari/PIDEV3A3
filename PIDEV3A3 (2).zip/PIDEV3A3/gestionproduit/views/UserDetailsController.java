/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionproduit.views;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author wiemj
 */
public class UserDetailsController implements Initializable {

    @FXML
    private TextField rNom;
    @FXML
    private TextField rPrenom;
    @FXML
    private TextField rmail;
    @FXML
    private TextField raddresse;
    @FXML
    private TextField rpassword;
    @FXML
    private TextField rId;
    @FXML
    private DatePicker rdate_naiss;
  @FXML
    private TextField rrole;
    @FXML
    private TextField rsexe;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    
    public void setrId(String value) {
        this.rId.setText(value);
    }   
    
    public void setrNom(String value) {
        this.rNom.setText(value);
    }

    public void setrPrenom(String value) {
        this.rPrenom.setText(value);
    }

    public void setRsexe(String value) {
        this.rsexe.setText(value);
    }

    public void setRdate_naiss(LocalDate value) {
        this.rdate_naiss.setValue(value);
    }

    public void setRmail(String value) {
        this.rmail.setText(value);
    }

    public void setRaddresse(String value) {
        this.raddresse.setText(value);
    }

    public void setRrole(String value) {
        this.rrole.setText(value);
    }

    public void setRpassword(String value) {
        this.rpassword.setText(value);
    }
    
    
}
