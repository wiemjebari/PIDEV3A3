/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI3;

import CentreGUI.AddCentre2Controller;
import Centreservice.CentreCRUD;
import Centreservice.ReservationCRUD;
import com.sun.org.apache.bcel.internal.generic.Select;
import entities.Centre;
import entities.Reservation_Centre;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import tools.MyConnection;

/**
 * FXML Controller class
 *
 * @author asmab
 */
public class Gestion_ReservationController implements Initializable {

    @FXML
    private Button btninsert;
    @FXML
    private Button btndelete;
    @FXML
    private Button btnupdate;

    @FXML
    private ComboBox<String> tfidcentre;
    private TextField tfidservice;
    @FXML
    private DatePicker tfdate;
    @FXML
    private TableView tvres;

    @FXML
    private TableColumn<Reservation_Centre, String> coluser;
    @FXML
    private TableColumn<Reservation_Centre, String> colservice;
    @FXML
    private TableColumn<Reservation_Centre, String> coldate;
    private Reservation_Centre selectedReservation;
    @FXML
    private ComboBox<String> tfservice;
    @FXML
    private TextField tfprix;
    @FXML
    private TableColumn<Reservation_Centre, Integer> colprix;
    @FXML
    private TableColumn<Reservation_Centre, Integer> colidres;
    @FXML
    private Button btnback;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // TODO
        showReservation_Centre();

        ObservableList<String> list1 = FXCollections.observableArrayList("SPA", "massage");
        tfservice.setItems(list1);
        ObservableList<String> list2 = FXCollections.observableArrayList("HELENA", "Beauty", "RELAX", "QUEEN", "BELLA", "JOELLE");
        tfidcentre.setItems(list2);

    }

    @FXML
    private void ajouterReservation(ActionEvent event) throws Exception {

        Reservation_Centre R = new Reservation_Centre();
        ReservationCRUD pcd = new ReservationCRUD();
        //  Reservation_Centre R=new Reservation_Centre();

        R.setNom_centre(tfidcentre.getValue()); 
        
        R.setServices(tfservice.getValue()); 
        R.setDate(tfdate.getValue().toString());
        R.setPrix(Integer.parseInt( tfprix.getText())); 
        System.err.println("test: "+R);
        pcd.ajouterReservation(R);

        JOptionPane.showMessageDialog(null, "Reservation ajoutée");
        Connection cnx;
        String query = "Select id_reservation from reservation_centre"; //selctionner de la base
ResultSet rs;

Statement st;

try {
cnx = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
 st = cnx.createStatement();
            rs = st.executeQuery(query);
            boolean last = rs.last();
            {
       JavaMailUt.sendMail("aleeboukesra@gmail.com",rs.getInt("id_reservation"),R.getNom_centre());

       
        JOptionPane.showMessageDialog(null, "Mail envoyé");
            }
            } catch (SQLException ex) {
            Logger.getLogger(Gestion_ReservationController.class.getName()).log(Level.SEVERE, null, ex);
        showReservation_Centre();
    }
    }

    @FXML
    public void supprimerReservation(ActionEvent event2) {
        if (selectedReservation != null) {
            ReservationCRUD pcd = new ReservationCRUD();
            pcd.supprimerReservation(selectedReservation);
            JOptionPane.showMessageDialog(null, "reservation supprimee");
            selectedReservation = null;
            showReservation_Centre();
        } else {
            JOptionPane.showMessageDialog(null, "selectionner a nouveau");
        }
    }

    public ObservableList<Reservation_Centre> getReservation_CentreList() {
        ObservableList<Reservation_Centre> Reservation_CentreList = FXCollections.observableArrayList();
        Connection cnx;
        String query = "Select * from  reservation_centre"; //selctionner de la base
        ResultSet rs;
        
        Statement st;

        try {
            cnx = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");

            st = cnx.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                Reservation_Centre res = new Reservation_Centre(rs.getInt("id_reservation"),rs.getString("nom_centre"),rs.getString("services"), rs.getString("date"), rs.getInt("prix_service"));

                Reservation_CentreList.add(res);
               // System.err.println(res);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Gestion_ReservationController.class.getName()).log(Level.SEVERE, null, ex);

        }
        return Reservation_CentreList;
    }

    public void showReservation_Centre() {
        ObservableList<Reservation_Centre> List = getReservation_CentreList();
        colidres.setCellValueFactory(new PropertyValueFactory<Reservation_Centre, Integer>("id_reservation"));
        coluser.setCellValueFactory(new PropertyValueFactory<Reservation_Centre, String>("nom_centre"));
        coldate.setCellValueFactory(new PropertyValueFactory<Reservation_Centre, String>("date"));
        colservice.setCellValueFactory(new PropertyValueFactory<Reservation_Centre, String>("services"));
        colprix.setCellValueFactory(new PropertyValueFactory<Reservation_Centre, Integer>("prix"));
        System.err.println(List);
        tvres.setItems(List);
    }

    @FXML
    public void test() {
        selectedReservation = (Reservation_Centre) tvres.getSelectionModel().getSelectedItems().get(0);
         System.out.println("nom_centre"+selectedReservation.getNom_centre());
        tfidcentre.setValue("" + selectedReservation.getNom_centre());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate l = LocalDate.parse(selectedReservation.getDate(), formatter);
        tfdate.setValue(l);
        tfservice.setValue("" + selectedReservation.getServices());
        tfprix.setText("" + selectedReservation.getPrix());

    }

    @FXML
    private void prixcalcule(ActionEvent event) {
        String s = (String) tfservice.getValue();

        if (s.equals("massage")) {
            tfprix.setText("40");
        } else if (s.equals("SPA")) {
            tfprix.setText("45");
        } else {
            tfprix.setText("0");

        }

    }
    @FXML
      public void welcome(ActionEvent event ) throws IOException{
      
    ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GeneralMainPackage/GeneralFrontPage.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }
     
}
