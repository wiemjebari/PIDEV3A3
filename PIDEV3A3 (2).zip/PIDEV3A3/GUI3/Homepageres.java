/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI3;

import CentreGUI.HomePage2;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author asmab
 */
public class Homepageres extends Application{
    
    @Override
    public void start(Stage primaryStage) {

   
            
       
        try {
            Parent root;
            root = FXMLLoader.load(getClass().getResource("Gestion_Reservation.fxml"));
         
             Scene scene1 = new Scene(root);
             
            primaryStage.setTitle("Hello Asma!");
            primaryStage.setScene(scene1);
            primaryStage.show();
    }
            catch (IOException ex) {
            Logger.getLogger(Homepageres.class.getName()).log(Level.SEVERE, null, ex);
        
        } 

        
    }
public static void main(String[] args) {
        launch(args);
    }}
            
        
      
    

