/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentreInterface;
import java.util.List;
/**
 *
 * @author asmab
 */
public interface ICentre<T>  {
   
     public void ajouterCentre(T t);
     public void supprimerCentre(T t);
     public void updateCentre(T t,String adr);
     public List<T> displayCentre();
}

