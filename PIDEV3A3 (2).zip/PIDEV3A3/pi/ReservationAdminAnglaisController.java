/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import Entities.Etat;
import Entities.ReservationRandonnees;
import Services.RandonneeService;
import Services.ReservationService;
import java.io.File;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ReservationAdminAnglaisController implements Initializable {

    RandonneeService rs = new RandonneeService();
    ReservationService res = new ReservationService();
    int id_selected_randonne=0,id_reservation=0;
    ObservableList<ReservationRandonnees> ReservationList = FXCollections.observableArrayList();
    Etat etatR;
    
    @FXML
    private ImageView imageVi;
    @FXML
    private Label heure_depart_r;
    @FXML
    private Label heure_retour_r;
    @FXML
    private Label prix_r;
    @FXML
    private Label nbr_place_r;
    @FXML
    private Label dateR;
    @FXML
    private TableView<ReservationRandonnees> table;
    @FXML
    private TableColumn<ReservationRandonnees, Integer> id;
    @FXML
    private TableColumn<ReservationRandonnees, String> lieu;
    @FXML
    private TableColumn<ReservationRandonnees, Date> date;
    @FXML
    private TableColumn<ReservationRandonnees, Double> prix;
    @FXML
    private TableColumn<ReservationRandonnees, Integer> place_reserve;
    @FXML
    private TableColumn<ReservationRandonnees, Etat> etat;
    @FXML
    private Label username;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        File file;
        file = new File("C://Users//ASUS//Downloads//ra.jpg");
        GaussianBlur blur = new GaussianBlur(20);       
        imageVi.setEffect(blur);
        imageVi.setImage(new Image(file.toURI().toString()));
        imageVi.setCache(true);
        try {
            // TODO
            afficher();
        } catch (SQLException ex) {
            Logger.getLogger(ReservationAdminController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

   

    @FXML
    private void modif(MouseEvent event) throws SQLException {
        if (event.getClickCount() == 1){
            table.setItems(ReservationList);
            ObservableList<ReservationRandonnees> allReservations,r ;
            allReservations=table.getItems();
            r=table.getSelectionModel().getSelectedItems();

            id_reservation=r.get(0).getId();
            etatR=r.get(0).getEtat();
            ReservationRandonnees reservation=new ReservationRandonnees();
            reservation=res.getById(id_reservation);
            username.setText(reservation.getNom_user());
            System.out.println(id_reservation);
        }
    }

    @FXML
    private void Confirmer(ActionEvent event) throws SQLException {
        if(etatR==Etat.ENATTENTE){
            if(res.getById(id_reservation)!=null)
                {

                    Etat etat;
                    etat=Etat.CONFIRME;
                    ReservationRandonnees r=new ReservationRandonnees();
                    r=res.getById(id_reservation);
                    r.setEtat(etat);
                    res.updateAdmin(r); 
                    System.out.println("Done ! "); 
                
                
        }
        else{
                    System.out.println("Reservation deja "+etatR);
         }
        }
        ReservationList.clear();
        afficher();
    }

    @FXML
    private void refuser(ActionEvent event) throws SQLException {
        if(etatR==Etat.ENATTENTE){
            if(res.getById(id_reservation)!=null)
                {

                    Etat etat;
                    etat=Etat.REFUSE;
                    ReservationRandonnees r=new ReservationRandonnees();
                    r=res.getById(id_reservation);
                    r.setEtat(etat);
                    res.updateAdmin(r); 
                    System.out.println("Done ! "); 
                
                
        }
        else{
                    System.out.println("Reservation deja "+etatR);
         }
        }
        ReservationList.clear();
        afficher();
    }
    
    private void afficher() throws SQLException {
        List<ReservationRandonnees> liste= new ArrayList<ReservationRandonnees>();
  
        liste = res.readAll();
        
        for (ReservationRandonnees aux : liste)
        {            
            ReservationList.add(new ReservationRandonnees(aux.getId(),aux.getDate(),aux.getEtat(),aux.getNom_user(),aux.getLieu_randonnee(),aux.getNbr_places(),aux.getPrix_randonnee(),aux.getPhoto(),aux.getId_user(),aux.getId_randonne()));
            table.setItems(ReservationList);    
        }
        id.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Integer>("id"));
    	lieu.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,String>("lieu_randonnee"));
        date.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Date>("date"));
    	place_reserve.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Integer>("nbr_places"));
    	prix.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Double>("prix_randonnee"));
        etat.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Etat>("etat"));

        table.setItems(ReservationList);

    }
    
}
