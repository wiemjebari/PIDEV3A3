/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import Entities.Randonnees;
import Services.RandonneeService;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class RandonneesAnglaisController implements Initializable {

    RandonneeService rs = new RandonneeService();
    int id_randonnee = 0;
    String url;
    ObservableList<Randonnees> RandonnesListe = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Randonnees, Integer> id;
    @FXML
    private TableColumn<Randonnees, String> lieu;
    @FXML
    private TableColumn<Randonnees, Date> date;
    @FXML
    private TableColumn<Randonnees, Integer> heure_depart;
    @FXML
    private TableColumn<Randonnees, Integer> heure_retour;
    @FXML
    private TableColumn<Randonnees, Integer> nbr_places;
    @FXML
    private TableColumn<Randonnees, Double> prix;
    @FXML
    private TableColumn<Randonnees, ImageView> photoView;
    @FXML
    private TableColumn<Randonnees, String> urlph;
    @FXML
    private Button photo;
    @FXML
    private TextField lieu_input;
    @FXML
    private TextField date_input;
    @FXML
    private TextField heure_depart_input;
    @FXML
    private TextField heure_retour_input;
    @FXML
    private TextField nbr_place_input;
    @FXML
    private TextField prix_input;
    @FXML
    private TableView<Randonnees> table;
    @FXML
    private ImageView imageVi;
    @FXML
    private Label url_photo;
    @FXML
    private DatePicker date_picker;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        File file;
        file = new File("C://Users//ASUS//Downloads//ra.jpg");
        imageVi.setImage(new Image(file.toURI().toString()));
        imageVi.setCache(true);
        try {
            afficher();
        } catch (SQLException ex) {
            Logger.getLogger(RandonneesController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void afficher() throws SQLException {
        List<Randonnees> liste = new ArrayList<Randonnees>();
        liste = rs.readAll();

        for (Randonnees aux : liste) {
            RandonnesListe.add(new Randonnees(aux.getId(), aux.getDate(), aux.getLieu(), aux.getHeure_depart(), aux.getHeure_retour(), aux.getNbr_place(), aux.getPhoto(), aux.getPrix(), aux.getPhotoV()));
            table.setItems(RandonnesListe);
        }
        id.setCellValueFactory(new PropertyValueFactory<Randonnees, Integer>("id"));
        lieu.setCellValueFactory(new PropertyValueFactory<Randonnees, String>("lieu"));
        date.setCellValueFactory(new PropertyValueFactory<Randonnees, Date>("date"));
        heure_depart.setCellValueFactory(new PropertyValueFactory<Randonnees, Integer>("heure_depart"));
        heure_retour.setCellValueFactory(new PropertyValueFactory<Randonnees, Integer>("heure_retour"));
        nbr_places.setCellValueFactory(new PropertyValueFactory<Randonnees, Integer>("nbr_place"));
        prix.setCellValueFactory(new PropertyValueFactory<Randonnees, Double>("prix"));
        photoView.setCellValueFactory(new PropertyValueFactory<Randonnees, ImageView>("photoV"));
        urlph.setCellValueFactory(new PropertyValueFactory<Randonnees, String>("photo"));

        table.setItems(RandonnesListe);

    }

    @FXML
    private void ajouterRandonnee(ActionEvent event) throws SQLException, IOException {
        /*java.util.Date datee= new java.util.Date(date_input.getText());
        java.sql.Date sqldate=new java.sql.Date(datee.getTime());*/

        DatePicker tmpdate = (DatePicker) date_picker;
        String date = (String) tmpdate.getValue().toString();
        date = date.substring(0, 4) + '/' + date.substring(5, 7) + '/' + date.substring(8);
        java.util.Date myDate = new java.util.Date(date);
        java.sql.Date sqldate = new java.sql.Date(myDate.getTime());

        File f=new File(url_photo.getText());

        Files.copy(Paths.get(url_photo.getText()),Paths.get("uploads//"+f.getName()),REPLACE_EXISTING);
        
        rs.add(new Randonnees(sqldate, lieu_input.getText(), heure_depart_input.getText(), heure_retour_input.getText(), Integer.parseInt(nbr_place_input.getText()), "uploads//"+f.getName(), Double.parseDouble(prix_input.getText())));
        
        RandonnesListe.clear();

        lieu_input.setText("");
        heure_depart_input.setText("");
        heure_retour_input.setText("");
        nbr_place_input.setText("");
        prix_input.setText("");

        afficher();
    }

    @FXML
    private void modifierRandonnee(ActionEvent event) throws SQLException {
        /*java.util.Date date= new java.util.Date(date_input.getText());
        java.sql.Date sqldat=new java.sql.Date(date.getTime());*/
        DatePicker tmpdate = (DatePicker) date_picker;
        String date = (String) tmpdate.getValue().toString();
        date = date.substring(0, 4) + '/' + date.substring(5, 7) + '/' + date.substring(8);
        java.util.Date myDate = new java.util.Date(date);
        java.sql.Date sqldate = new java.sql.Date(myDate.getTime());
        System.out.println("test");
        rs.update(new Randonnees(id_randonnee, sqldate, lieu_input.getText(), heure_depart_input.getText(), heure_retour_input.getText(), Integer.parseInt(nbr_place_input.getText()), url_photo.getText(), Double.parseDouble(prix_input.getText())));
        RandonnesListe.clear();

        lieu_input.setText("");
        heure_depart_input.setText("");
        heure_retour_input.setText("");
        nbr_place_input.setText("");
        prix_input.setText("");

        afficher();
    }

    @FXML
    private void supprimerRandonnee(ActionEvent event) throws SQLException {
        rs.delete(id_randonnee);
        RandonnesListe.clear();
        lieu_input.setText("");

        heure_depart_input.setText("");
        heure_retour_input.setText("");
        nbr_place_input.setText("");
        prix_input.setText("");
        afficher();
    }

    @FXML
    private void modif(MouseEvent event) throws SQLException {
        if (event.getClickCount() == 1) {
            table.setItems(RandonnesListe);
            ObservableList<Randonnees> allRandonnees, r;
            allRandonnees = table.getItems();
            r = table.getSelectionModel().getSelectedItems();

            lieu_input.setText(String.valueOf(r.get(0).getLieu()));
            java.util.Date utilDate = new java.util.Date(r.get(0).getDate().getTime());
            LocalDate date = utilDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

            date_picker.setValue(date);
            heure_depart_input.setText(String.valueOf(r.get(0).getHeure_depart()));
            heure_retour_input.setText(String.valueOf(r.get(0).getHeure_retour()));
            nbr_place_input.setText(String.valueOf(r.get(0).getNbr_place()));
            prix_input.setText(String.valueOf(r.get(0).getPrix()));
            id_randonnee = r.get(0).getId();
            url_photo.setText(r.get(0).getPhoto());
        } else if (event.getClickCount() == 2) {
            table.setItems(RandonnesListe);
            ObservableList<Randonnees> allRandonnees, r;
            allRandonnees = table.getItems();
            r = table.getSelectionModel().getSelectedItems();

            id_randonnee = r.get(0).getId();
            double Gain = rs.calculGain(id_randonnee);

            JOptionPane.showMessageDialog(null, " \n Gain de la randonnee " + r.get(0).getLieu() + " est " + Gain + " DT");
        }
    }

    @FXML
    private void upload(ActionEvent event) {
        FileChooser fc = new FileChooser();
        File file;
        file = fc.showOpenDialog(null);
        String path = file.getPath();
        url_photo.setText(path);
        url = path;
    }

}
