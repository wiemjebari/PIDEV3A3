/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import Entities.Randonnees;
import Services.RandonneeService;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class AcceuilController implements Initializable {

    RandonneeService rs = new RandonneeService();
    @FXML
    private ImageView imageVi;
    ObservableList<Randonnees> RandonnesListe = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Randonnees, Integer> id;
    @FXML
    private TableColumn<Randonnees, String> lieu;
    @FXML
    private TableColumn<Randonnees, Date> date;
    @FXML
    private TableColumn<Randonnees, Integer> heure_depart;
    @FXML
    private TableColumn<Randonnees, Integer> heure_retour;
    @FXML
    private TableColumn<Randonnees, Integer> nbr_places;
    @FXML
    private TableColumn<Randonnees, Double> prix;
    @FXML
    private TableColumn<Randonnees, ImageView> photo;
    @FXML
    private TableView<Randonnees> table;
    @FXML
    private Label heure_depart_r;
    @FXML
    private Label heure_retour_r;
    @FXML
    private Label prix_r;
    @FXML
    private Label nbr_place_r;
    @FXML
    private Label dateR;
    @FXML
    private TextField recherche;
    @FXML
    private CheckBox max4;
    @FXML
    private CheckBox max6;
    @FXML
    private CheckBox max1;
    /**
     * Initializes the controller class.
     */
    private void afficher() throws SQLException {
        List<Randonnees> liste= new ArrayList<Randonnees>();
        liste = rs.readAll();
        
        for (Randonnees aux : liste)
        {
            RandonnesListe.add(new Randonnees(aux.getId(), aux.getDate(), aux.getLieu(), aux.getHeure_depart(), aux.getHeure_retour(),aux.getNbr_place(),aux.getPhoto(),aux.getPrix(),aux.getPhotoV()));
            table.setItems(RandonnesListe);    
        }
        id.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("id"));
    	lieu.setCellValueFactory(new PropertyValueFactory<Randonnees,String>("lieu"));
        date.setCellValueFactory(new PropertyValueFactory<Randonnees,Date>("date"));
    	heure_depart.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_depart"));
        heure_retour.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_retour"));
        nbr_places.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("nbr_place"));
    	prix.setCellValueFactory(new PropertyValueFactory<Randonnees,Double>("prix"));
        photo.setCellValueFactory(new PropertyValueFactory<Randonnees,ImageView>("photoV"));

        table.setItems(RandonnesListe);

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            // TODO
            afficher();
        } catch (SQLException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void rech(KeyEvent event) throws SQLException {
        List<Randonnees> listeRandonnees=new ArrayList<Randonnees>();
        listeRandonnees=rs.recherche(recherche.getText());
        RandonnesListe.clear();
        for (Randonnees aux : listeRandonnees)
        {
            RandonnesListe.add(new Randonnees(aux.getId(), aux.getDate(), aux.getLieu(), aux.getHeure_depart(), aux.getHeure_retour(),aux.getNbr_place(),aux.getPhoto(),aux.getPrix(),aux.getPhotoV()));
            table.setItems(RandonnesListe);    
        }
           id.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("id"));
    	lieu.setCellValueFactory(new PropertyValueFactory<Randonnees,String>("lieu"));
        date.setCellValueFactory(new PropertyValueFactory<Randonnees,Date>("date"));
    	heure_depart.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_depart"));
        heure_retour.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_retour"));
        nbr_places.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("nbr_place"));
    	prix.setCellValueFactory(new PropertyValueFactory<Randonnees,Double>("prix"));
        photo.setCellValueFactory(new PropertyValueFactory<Randonnees,ImageView>("photoV"));

        table.setItems(RandonnesListe);
    }

    @FXML
    private void max40(ActionEvent event) throws SQLException {
        List<Randonnees> listeRandonnees=new ArrayList<Randonnees>();
        listeRandonnees=rs.FiltrePrix(40);
        RandonnesListe.clear();
        for (Randonnees aux : listeRandonnees)
        {
            RandonnesListe.add(new Randonnees(aux.getId(), aux.getDate(), aux.getLieu(), aux.getHeure_depart(), aux.getHeure_retour(),aux.getNbr_place(),aux.getPhoto(),aux.getPrix(),aux.getPhotoV()));
            table.setItems(RandonnesListe);    
        }
        id.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("id"));
    	lieu.setCellValueFactory(new PropertyValueFactory<Randonnees,String>("lieu"));
        date.setCellValueFactory(new PropertyValueFactory<Randonnees,Date>("date"));
    	heure_depart.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_depart"));
        heure_retour.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_retour"));
        nbr_places.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("nbr_place"));
    	prix.setCellValueFactory(new PropertyValueFactory<Randonnees,Double>("prix"));
        photo.setCellValueFactory(new PropertyValueFactory<Randonnees,ImageView>("photoV"));

        table.setItems(RandonnesListe);
    }

    @FXML
    private void max60(ActionEvent event) throws SQLException {
        if(!max4.isSelected()){
            List<Randonnees> listeRandonnees=new ArrayList<Randonnees>();
        listeRandonnees=rs.FiltrePrix(60);
        RandonnesListe.clear();
        for (Randonnees aux : listeRandonnees)
        {
            RandonnesListe.add(new Randonnees(aux.getId(), aux.getDate(), aux.getLieu(), aux.getHeure_depart(), aux.getHeure_retour(),aux.getNbr_place(),aux.getPhoto(),aux.getPrix(),aux.getPhotoV()));
            table.setItems(RandonnesListe);    
        }
        id.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("id"));
    	lieu.setCellValueFactory(new PropertyValueFactory<Randonnees,String>("lieu"));
        date.setCellValueFactory(new PropertyValueFactory<Randonnees,Date>("date"));
    	heure_depart.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_depart"));
        heure_retour.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_retour"));
        nbr_places.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("nbr_place"));
    	prix.setCellValueFactory(new PropertyValueFactory<Randonnees,Double>("prix"));
        photo.setCellValueFactory(new PropertyValueFactory<Randonnees,ImageView>("photoV"));

        table.setItems(RandonnesListe);
        }
        
    }

    @FXML
    private void max100(ActionEvent event) throws SQLException {
        List<Randonnees> listeRandonnees=new ArrayList<Randonnees>();
        listeRandonnees=rs.FiltrePrix(100);
        RandonnesListe.clear();
        for (Randonnees aux : listeRandonnees)
        {
            RandonnesListe.add(new Randonnees(aux.getId(), aux.getDate(), aux.getLieu(), aux.getHeure_depart(), aux.getHeure_retour(),aux.getNbr_place(),aux.getPhoto(),aux.getPrix(),aux.getPhotoV()));
            table.setItems(RandonnesListe);    
        }
        id.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("id"));
    	lieu.setCellValueFactory(new PropertyValueFactory<Randonnees,String>("lieu"));
        date.setCellValueFactory(new PropertyValueFactory<Randonnees,Date>("date"));
    	heure_depart.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_depart"));
        heure_retour.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("heure_retour"));
        nbr_places.setCellValueFactory(new PropertyValueFactory<Randonnees,Integer>("nbr_place"));
    	prix.setCellValueFactory(new PropertyValueFactory<Randonnees,Double>("prix"));
        photo.setCellValueFactory(new PropertyValueFactory<Randonnees,ImageView>("photoV"));

        table.setItems(RandonnesListe);
    }

    

  
    
}
