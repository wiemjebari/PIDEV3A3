/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import Entities.Etat;
import static Entities.Etat.*;
import Entities.Randonnees;
import Entities.ReservationRandonnees;
import Services.RandonneeService;
import Services.ReservationService;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author ASUS
 */
public class Pi extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("ChoixLangue.fxml")); 
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, IOException {
        launch(args);
        
        /*RandonneeService rs =new RandonneeService();
        ReservationService reService=new ReservationService();

              
        int choix=-1;
        while(choix<1 || choix >13){
            
            System.out.println("Ajouter une randonnee: 1");
            System.out.println("Afficher toutes les randonnees: 2");
            System.out.println("Modifier randonné: 3");
            System.out.println("Supprimer randonné: 4");
            System.out.println("Calculer le gain d une randonnee donnee: 5");
            System.out.println("Rechercher de randonne par lieu: 6");
            System.out.println("Filtrer et trier randonnees par prix max 7");
            System.out.println("Ajouter une reservation: 8");
            System.out.println("Afficher toutes les reservations: 9");
            System.out.println("Modifier reservation: 10");
            System.out.println("Supprimer reservation: 11");
            System.out.println("Confirmer une reservation: 12");
            System.out.println("liste des reservations de l'utilisateur : 13");
            
            
            Scanner choixMax = new Scanner(System.in);
            System.out.println("entrer le choix: ");
            choix = choixMax.nextInt();
        
        switch(choix){
            case 1:{
                //ajout Randonnees***************************************************************************************
        
       
        Scanner dateInput = new Scanner(System.in);
        System.out.println("Entrer la date de la randonnée: ");
        String date = dateInput.nextLine();
        java.util.Date datee= new java.util.Date(date);
        java.sql.Date sqldate=new java.sql.Date(datee.getTime());
        
        Scanner LieuInput = new Scanner(System.in);
        System.out.println("Entrer le lieu de la randonnée: ");
        String lieu = LieuInput.nextLine();
        
        
        int nbr_place=-1;
        while(nbr_place<0 ){
            Scanner nbr_placeInput = new Scanner(System.in);
            System.out.println("Entrer nombre des places de la randonnée: ");
            nbr_place = nbr_placeInput.nextInt();
        }
        
        
        int heure_depart=-1;
        while(heure_depart<0 || heure_depart>10){
            Scanner heure_departInput = new Scanner(System.in);
            System.out.println("Entrer heure_depart de la randonnée: ");
            heure_depart = heure_departInput.nextInt();
        }
        
        int heure_retour=-1;
        while(heure_retour<0 || heure_retour>23 || heure_retour<heure_depart){
            Scanner heure_retourInput = new Scanner(System.in);
            System.out.println("Entrer heure_retour de la randonnée: ");
            heure_retour = heure_retourInput.nextInt();
        }
        
        String photo="url/photo";
        
        double prix =-1;
        while(prix<0 ){
            Scanner prixInput = new Scanner(System.in);
            System.out.println("Entrer prix de la randonnée: ");
            prix = prixInput.nextDouble();
        }
        Randonnees r1=new Randonnees(sqldate,lieu,heure_depart,heure_retour,nbr_place,photo,prix);
        rs.add(r1);
        
        
            }
            break;
            case 2:{
                //affichage Randonnees***************************************************************************************
        
                System.out.println("   Liste des randonnées");
                List<Randonnees> liste=new ArrayList<Randonnees>();
                liste=rs.readAll();
                for(Randonnees r : liste){
                    System.out.println(r.toString()+"nombre des places Dispo="+(r.getNbr_place()-reService.CalculNbr_ReservationExistant(r.getId())));
                }
                
            }
            break;
            case 3:{
                //update randonnees ***************************************************************************************
                Scanner id_randoInput = new Scanner(System.in);
                System.out.println("Modification:Entrer id de la randonnée: ");
                int id_randonnee = id_randoInput.nextInt();
                if(rs.getById(id_randonnee)!=null){
                    
                Scanner dateInput = new Scanner(System.in);
                System.out.println("Entrer la date de la randonnée: ");
                String date = dateInput.nextLine();
                java.util.Date datee= new java.util.Date(date);
                java.sql.Date sqldate=new java.sql.Date(datee.getTime());
        
                Scanner LieuInput = new Scanner(System.in);
                System.out.println("Entrer le lieu de la randonnée: ");
                String lieu = LieuInput.nextLine();
        
        
                int nbr_place=-1;
                while(nbr_place<0 ){
                    Scanner nbr_placeInput = new Scanner(System.in);
                    System.out.println("Entrer nombre des places de la randonnée: ");
                    nbr_place = nbr_placeInput.nextInt();
                }
        
        
                int heure_depart=-1;
                while(heure_depart<0 || heure_depart>10){
                    Scanner heure_departInput = new Scanner(System.in);
                    System.out.println("Entrer heure_depart de la randonnée: ");
                    heure_depart = heure_departInput.nextInt();
                }
        
                int heure_retour=-1;
                while(heure_retour<0 || heure_retour>23 || heure_retour<heure_depart){
                    Scanner heure_retourInput = new Scanner(System.in);
                    System.out.println("Entrer heure_retour de la randonnée: ");
                    heure_retour = heure_retourInput.nextInt();
                }
        
                String photo="url/photo";
        
                double prix =-1;
                while(prix<0 ){
                    Scanner prixInput = new Scanner(System.in);
                    System.out.println("Entrer prix de la randonnée: ");
                    prix = prixInput.nextDouble();
                }
                Randonnees r1=new Randonnees(id_randonnee,sqldate,lieu,heure_depart,heure_retour,nbr_place,photo,prix);

                    rs.update(r1);
                }
                else{
                   System.out.println("randonnee n existe pas ");  
                }
                
                 
            }
            break;
            case 4:{
                //supprimer randonnees ***************************************************************************************
                Scanner id_randoInput = new Scanner(System.in);
                System.out.println("Suppression:Entrer id de la randonnée: ");
                int id_randonnee = id_randoInput.nextInt();
                if(rs.getById(id_randonnee)!=null){
                    rs.delete(id_randonnee);
                }
                else{
                   System.out.println("randonnee n existe pas "); 
                }
               
                
            }
            break;
            case 5:{
                //Calcul Gain ADDDminn***************************************************************************************
        
                Scanner inputid_rando = new Scanner(System.in);
                System.out.print("Calculer Gain d une randonné:Entrer id de randonné : ");
                int id_randonnee = inputid_rando.nextInt();
                if(rs.getById(id_randonnee)!=null){
                    double Gain=rs.calculGain(id_randonnee);
                    System.out.println(Gain); 
                }
                else{
                    System.out.println("randonnee n existe pas");
                }
                
            }
            break;
            case 6:{
                // Recherche avancé ***************************************************************************************
        
                Scanner inputrecherche = new Scanner(System.in);
                System.out.print("recherche avancé: ");
                String str = inputrecherche.nextLine();
            
                System.out.println("   Liste des randonnées");
                List<Randonnees> listeRandonnees=new ArrayList<Randonnees>();
                listeRandonnees=rs.recherche(str);
                for(Randonnees r : listeRandonnees){
                    System.out.println(r.toString()+"nombre des places Dispo="+(r.getNbr_place()-reService.CalculNbr_ReservationExistant(r.getId())));
                }
                
            }
            break;
            case 7:{
                //filtre randonnée par prix
        
                Scanner inputPrixMax = new Scanner(System.in);
                System.out.print("Prix max: ");
                double prixMax = inputPrixMax.nextDouble();
        
                System.out.println("   Liste des randonnées(Filtre)");
                List<Randonnees> listeRandonnees=new ArrayList<Randonnees>();
                listeRandonnees=rs.FiltrePrix(prixMax);
                for(Randonnees r : listeRandonnees){
                    System.out.println(r.toString()+"nombre des places Dispo="+(r.getNbr_place()-reService.CalculNbr_ReservationExistant(r.getId())));
                }
               
            }
            break;
            case 8:{
                //ajout Reservation ***************************************************************************************
        
                //session user
                int id_user=15;
                Scanner input = new Scanner(System.in);
                System.out.print("Entrer id_randonnée: ");
                int id_randonnee = input.nextInt();
        
                if(rs.getById(id_randonnee)!=null){
        
                int nbr_places_dispo=rs.getById(id_randonnee).getNbr_place() - reService.CalculNbr_ReservationExistant(id_randonnee) ;
        
                if(nbr_places_dispo > 0){
                    LocalDate currentDate = LocalDate.now();
                    java.sql.Date sqlDate = java.sql.Date.valueOf(currentDate);
                    ReservationRandonnees reservation=new ReservationRandonnees(sqlDate,ENATTENTE,id_user,id_randonnee);
                    reService.add(reservation);
                }
                else{
                    System.out.println("Randonne complet!");
                }
                }
                else{
                    System.out.println("Randonnee n existe pas!");
                }
                
        
            }
            break;
            case 9:{
                //affichage Réservations ***************************************************************************************
        
                System.out.println("   Liste des réservations");
                List<ReservationRandonnees> listeRes=new ArrayList<ReservationRandonnees>();
                listeRes=reService.readAll();
                for(ReservationRandonnees r : listeRes){
                    System.out.println(r.toString());
                }
                
            }
            break;
            case 10:{
                //update reservation***************************************************************************************
        
                    Scanner input = new Scanner(System.in);
                    System.out.print("Modifier:Entrer id de reservation a modifier: ");
                    int id = input.nextInt();
                    if(reService.getById(id)!=null)
                    {
                        Scanner inputid_randonne = new Scanner(System.in);
                        int id_randonnee=0 ;
                        while(rs.getById(id_randonnee)==null){
                        System.out.print("Entrer id de la nouvelle randonnee: ");
                        id_randonnee = inputid_randonne.nextInt();
                    }
                    ReservationRandonnees r=new ReservationRandonnees();
                    r=reService.getById(id);
                    r.setId_randonne(id_randonnee);
                    reService.update(r); 
                    System.out.print("Reservation modifiée ");
                }
                else{
                    System.out.print("Reservation n existe pas ");
                }
               
            }
            break;
            case 11:{
                //supprimer reservation***************************************************************************************
         
                Scanner input = new Scanner(System.in);
                System.out.print("Supprimer:Entrer id de reservation: ");
                int id = input.nextInt();
                reService.delete(id);
               
            }
            break;
            case 12:{
                //Confiramation reservation ADDDminn***************************************************************************************
        
                Scanner inputreserv = new Scanner(System.in);
                System.out.print("Admin: Entrer id de reservation: ");
                int id = inputreserv.nextInt();
                if(reService.getById(id)!=null)
                {
                    if(reService.getByIdEtat(id)!=null){
                    Scanner choixinput = new Scanner(System.in);
                    System.out.println("Admin: pour confirmer 1 pour refuser 0: ");
                    int choixEtat = choixinput.nextInt();
                    Etat etat;
                    if(choixEtat==1){
                        etat=Etat.CONFIRME;
                    }
                    else{
                        etat=Etat.REFUSE;
                    }
                    ReservationRandonnees r=new ReservationRandonnees();
                    r=reService.getById(id);
                    r.setEtat(etat);
                    reService.updateAdmin(r); 
                    System.out.println("Done ! "); 
                }
                else{
                    System.out.println("Reservation deja confirmé ou refusé ");
                }
            
                }
                else{
                    System.out.println("Reservation n existe pas ");
                }
                ;
            }
            break;
            case 13:{
                //session user
                int id_user=15;
                System.out.println("   mes réservations");
                List<ReservationRandonnees> listeRes=new ArrayList<ReservationRandonnees>();
                listeRes=reService.readByUser(id_user);
                for(ReservationRandonnees r : listeRes){
                    System.out.println(r.toString());
                }
                
            }
            break;
            
        }
        int menu=-1;
        while(menu<0 ||menu>1){
            Scanner menuInput = new Scanner(System.in);
            System.out.println("retourner menu :1 pour quitter :0");
            menu = menuInput.nextInt();
        }
        
        
        if(menu ==1){
            choix=-1;  
        }
        
       }*/
       
    }
    
}
