/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ChoixLangueController implements Initializable {

    @FXML
    private ImageView imageVi;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        File file;
        file = new File("");
        imageVi.setImage(new Image(file.toURI().toString()));
        imageVi.setCache(true);
    }    

    @FXML
    private void francais(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Stage mywindow=(Stage) imageVi.getScene().getWindow();
        
        Scene scene = new Scene(root);
        mywindow.setScene(scene);
        mywindow.show();
        
    }

    @FXML
    private void english(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLEnglais.fxml"));
        Stage mywindow=(Stage) imageVi.getScene().getWindow();
        
        Scene scene = new Scene(root);
        mywindow.setScene(scene);
        mywindow.show();
    }
    
    @FXML
    private void loadback(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GeneralMainPackage/GeneralBackPage.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }
    
}
