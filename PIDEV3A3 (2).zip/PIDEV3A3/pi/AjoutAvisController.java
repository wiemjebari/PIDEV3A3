/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import Entities.Avis;
import Services.AvisService;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import org.controlsfx.control.Rating;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class AjoutAvisController implements Initializable {

    AvisService as=new AvisService();
    private int rt;
    private int id_user;
    private int id_randonne;
    
    @FXML
    private Rating rating;
    @FXML
    private Label labelRating;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        rating.ratingProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                labelRating.setText(newValue.toString());
                rt=newValue.intValue();
                System.out.println(newValue);
            }
        });
        labelRating.setVisible(false);
    }

    @FXML
    private void envoyer(ActionEvent event) throws SQLException {
        
        as.add(new Avis(rt,id_user,id_randonne));
    }
    
    public void setData(int id_user,int id_randonne){
        this.id_randonne=id_randonne;
        this.id_user=id_user;
    }

    
}
