/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class FXMLEnglaisController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private AnchorPane affichage;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        AnchorPane root;
        try {
            root = FXMLLoader.load(getClass().getResource("AcceuilEnglais.fxml"));
            affichage.getChildren().setAll(root);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }    

    @FXML
    private void Admin(ActionEvent event) throws IOException {
        AnchorPane root = FXMLLoader.load(getClass().getResource("randonneesAnglais.fxml"));
        affichage.getChildren().setAll(root);
    }

    @FXML
    private void utilisateur(ActionEvent event) throws IOException {
        AnchorPane root = FXMLLoader.load(getClass().getResource("ReservationAnglais.fxml"));
        affichage.getChildren().setAll(root);
    }

    @FXML
    private void reservationAdmin(ActionEvent event) throws IOException {
        AnchorPane root = FXMLLoader.load(getClass().getResource("ReservationAdminAnglais.fxml"));
        affichage.getChildren().setAll(root);
    }

     @FXML
    private void langue(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChoixLangue.fxml"));
        Stage mywindow=(Stage) affichage.getScene().getWindow();
        
        Scene scene = new Scene(root);
        mywindow.setScene(scene);
        mywindow.show();
    }

    @FXML
    private void Acceuil(ActionEvent event) throws IOException {
        AnchorPane root;
        root = FXMLLoader.load(getClass().getResource("AcceuilEnglais.fxml"));
        affichage.getChildren().setAll(root);
    }
    
}
