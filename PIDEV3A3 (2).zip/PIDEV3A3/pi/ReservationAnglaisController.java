/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pi;

import Entities.Etat;
import static Entities.Etat.ENATTENTE;
import Entities.Randonnees;
import Entities.ReservationRandonnees;
import Services.RandonneeService;
import Services.ReservationService;
import java.io.File;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ReservationAnglaisController implements Initializable {
RandonneeService rs = new RandonneeService();
    ReservationService res = new ReservationService();
    
    
    @FXML
    private ComboBox<String> randonnee;
    @FXML
    private TableView<ReservationRandonnees> table;
    @FXML
    private TableColumn<ReservationRandonnees, Integer> id;
    @FXML
    private TableColumn<ReservationRandonnees, String> lieu;
    @FXML
    private TableColumn<ReservationRandonnees, Date> date;
    @FXML
    private TableColumn<ReservationRandonnees, Double> prix;
    @FXML
    private TableColumn<ReservationRandonnees, ImageView> photo;
    @FXML
    private TableColumn<ReservationRandonnees, Integer> place_reserve;
    @FXML
    private TableColumn<ReservationRandonnees, Etat> etat;
    
    @FXML
    private Label heure_depart_r;
    @FXML
    private Label heure_retour_r;
    @FXML
    private Label prix_r;
    @FXML
    private Label nbr_place_r;
    @FXML
    private Label dateR;
    @FXML
    private TextField nbr;
    /**
     * Initializes the controller class.
     */
    int id_selected_randonne=0,id_reservation=0;
    ObservableList<ReservationRandonnees> ReservationList = FXCollections.observableArrayList();
    @FXML
    private ImageView imageVi;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        File file;
        file = new File("C://Users//ASUS//Downloads//ra.jpg");
        GaussianBlur blur = new GaussianBlur(20);       
        imageVi.setEffect(blur);
        imageVi.setImage(new Image(file.toURI().toString()));
        imageVi.setCache(true);
        // TODO
        randonnee.setItems(FXCollections.observableArrayList(getData()));
        try {
            afficher();
        } catch (SQLException ex) {
            Logger.getLogger(ReservationsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }   
    
    private List<String> getData() {
        List<String> strings = new ArrayList<>();
        try {
            strings =rs.getLieux();
            return strings;
        } catch (SQLException ex) {
            return null;
        }
    }

   

    @FXML
    private void modifierRandonnee(ActionEvent event) throws SQLException {
        //session user
        int id_user=15;
        LocalDate currentDate = LocalDate.now();
        java.sql.Date sqlDate = java.sql.Date.valueOf(currentDate);
        if(id_reservation!=0){
            res.update(new ReservationRandonnees(id_reservation,sqlDate,ENATTENTE,id_user,id_selected_randonne,Integer.parseInt(nbr.getText())));
        }
        nbr.setText("");
        ReservationList.clear();
        afficher();
    }

    @FXML
    private void ajouterRandonnee(ActionEvent event) throws SQLException {
        //session user
        int id_user=15;
        LocalDate currentDate = LocalDate.now();
        java.sql.Date sqlDate = java.sql.Date.valueOf(currentDate);
        if(id_selected_randonne!=0){
            res.add(new ReservationRandonnees(sqlDate,ENATTENTE,id_user,id_selected_randonne,Integer.parseInt(nbr.getText())));
        }
        Clear();
        nbr.setText("");
        ReservationList.clear();
        afficher();
    }

    @FXML
    private void modif(MouseEvent event) {
        if (event.getClickCount() == 1){
            
            Clear();
            table.setItems(ReservationList);
            ObservableList<ReservationRandonnees> allReservations,r ;
            allReservations=table.getItems();
            r=table.getSelectionModel().getSelectedItems();
            if((r.get(0).getEtat()!=Etat.CONFIRME)&&(r.get(0).getEtat()!=Etat.REFUSE)){
                nbr.setText(String.valueOf(r.get(0).getNbr_places()));
                id_reservation=r.get(0).getId();
            }
            else{
                nbr.setText("");
                id_reservation=0;
            }
            
        }
    }

    @FXML
    private void getReservation(ActionEvent event) throws SQLException {
        Randonnees r =new Randonnees();
        if(rs.getByLieu(randonnee.getValue()) !=null ){
            r=rs.getByLieu(randonnee.getValue());
            System.out.println(r.toString());
            dateR.setText(r.getDate().toString());
            heure_depart_r.setText(String.valueOf(r.getHeure_depart()));
            heure_retour_r.setText(String.valueOf(r.getHeure_retour()));
            nbr_place_r.setText(String.valueOf(r.getNbr_restant()));
            prix_r.setText(String.valueOf(r.getPrix()));
            id_selected_randonne=r.getId();
        }
        else{
            id_selected_randonne=0;
            dateR.setText("");
            heure_depart_r.setText("");
            heure_retour_r.setText("");
            nbr_place_r.setText("");
            prix_r.setText("");
        }
    }

    private void afficher() throws SQLException {
        List<ReservationRandonnees> liste= new ArrayList<ReservationRandonnees>();
        //session user
        int id_user=15;
        liste = res.readByUser(id_user);
        
        for (ReservationRandonnees aux : liste)
        {            
            ReservationList.add(new ReservationRandonnees(aux.getId(),aux.getDate(),aux.getEtat(),aux.getNom_user(),aux.getLieu_randonnee(),aux.getNbr_places(),aux.getPrix_randonnee(),aux.getPhoto(),aux.getId_user(),aux.getId_randonne()));
            table.setItems(ReservationList);    
        }
        id.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Integer>("id"));
    	lieu.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,String>("lieu_randonnee"));
        date.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Date>("date"));
    	place_reserve.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Integer>("nbr_places"));
    	prix.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Double>("prix_randonnee"));
        photo.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,ImageView>("photo"));
        etat.setCellValueFactory(new PropertyValueFactory<ReservationRandonnees,Etat>("etat"));

        table.setItems(ReservationList);

    }


     private void Clear(){
          id_selected_randonne=0;
            dateR.setText("");
            heure_depart_r.setText("");
            heure_retour_r.setText("");
            nbr_place_r.setText("");
            prix_r.setText("");
     }

    @FXML
    private void supprimerReservation(ActionEvent event) throws SQLException {
        if(id_reservation!=0){
            res.delete(id_reservation);
            ReservationList.clear();      
            nbr.setText("");
            afficher();
        }
        
    }


   
        
}
