/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentreGUI;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author asmab
 */
public class CentreDetailsController implements Initializable {
    @FXML
    private TextField rID;
    @FXML
    private TextField rNOM;
    
     private TextField rADR;
     private TextField rSER;
        private TextField rTel;
        private TextField rMail;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
    public void setrID(String value) {
          this.rADR.setText(value);
    }

    public void setrNOM(String value) {
          this.rNOM.setText(value);
    }

    public void setrADR(String value) {
        
        this.rADR.setText(value);
    }
     public void setrSER(String value) {
        
        this.rSER.setText(value);
    }
      public void setrTel(String value) {
        
        this.rTel.setText(value);
    }
       public void setrMail(String value) {
        
        this.rMail.setText(value);
    }

  

    
    
}
