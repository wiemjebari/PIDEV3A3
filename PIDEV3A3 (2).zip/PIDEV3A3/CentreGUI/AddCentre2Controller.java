/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentreGUI;
import Centreservice.CentreCRUD;
import com.sun.javafx.scene.control.behavior.TableViewBehavior;
import entities.Centre;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Observable;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;
import static sun.security.jgss.GSSUtil.login;
import tools.MyConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import static java.util.Collections.list;
import java.util.stream.Collectors;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author asmab
 */
public class AddCentre2Controller implements Initializable {

    @FXML
    private AnchorPane tf;
    @FXML
    private Button tfbtn;
    @FXML
    private Button btnSupp;
    @FXML
    private Button btnUp;
   
    @FXML
    private TextField tfNom;
    @FXML
    private TextField tfAdr;
    @FXML
    private TextField tfService;
    @FXML
    private TextField tfNum;
    @FXML
    private TextField tfemail;
     @FXML
    public TableView <Centre> tvcentre;
    @FXML
    private TableColumn<Centre,Integer> colID;
    @FXML
    private TableColumn<Centre,String> colNom;
    @FXML
    private TableColumn<Centre, String> colADR;
    @FXML
    private TableColumn<Centre, String> colSer;
    @FXML
    private TableColumn<Centre, Integer> colTel;
    @FXML
    private TableColumn<Centre, String> colMail;
    
    private Centre selectedCentre;
    @FXML
    private TextField tfrech;
@FXML
    private Button btnback;
    /**
     * Initializes the controller class.
     */
     private final ObservableList<Centre> dataList = FXCollections.observableArrayList();
    public ObservableList<Centre> liste = FXCollections.observableArrayList();
    public ObservableList<Centre>centresList=FXCollections.observableArrayList();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showcentre();
        // TODO
        tfrech.textProperty().addListener((Observable, oldValue, newValue) -> {
                    tvcentre.setItems(centresList.stream().filter(u-> {
                        return u.getNom_centre().toUpperCase().contains(newValue.toUpperCase()) || u.getAdresse().contains(newValue) ;}).collect(Collectors.toCollection(FXCollections::observableArrayList)));
                });
        
        
    }    

    @FXML
    private void ajouterCentre(ActionEvent event) {
        try{
            //// ajout d un  Centre dans la  DB
            
            String resNom = tfNom.getText();
            String resadresse = tfAdr.getText();
            String resservice = tfService.getText();
            String resnumtel = tfNum.getText();
            String resemail = tfemail.getText();
            Centre t = new Centre(1,resNom,resadresse,resservice,71560317,resemail);
            CentreCRUD pcd = new CentreCRUD();
            pcd.ajouterCentre(t);
           // JOptionPane.showMessageDialog(null, "Centre ajouté");
           Notifications n=Notifications.create().title("centre ajoute avec succes").text(" bienvenu!").graphic(null)
                     .hideAfter(Duration.seconds(10)).position(Pos.TOP_RIGHT)
                     .onAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    System.out.println("Clicked on notification");
                }
            });
        n.showConfirm();
            showcentre();
             }
     
            catch (Exception ex) {
            Logger.getLogger(AddCentre2Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //creation d une liste centre
        public ObservableList<Centre>getCentresList(){
          ObservableList<Centre>centresList=FXCollections.observableArrayList();
            Connection cnx;
            String query="Select * from centre";//selctionner de la base
            Statement st;
            ResultSet rs;
            Centre centre;
        
           
             try {
                    cnx = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root", "");
             
            
            st=cnx.createStatement();
            rs=st.executeQuery(query);
            
                 while (rs.next()) {
                     centre = new Centre(rs.getInt("id"),rs.getString("nom_Centre"),rs.getString("adresse"),
                 rs.getString("services"),rs.getInt("num_tel"),rs.getString("e_mail"));
                     centresList.add(centre);
                     
                 }
                    } catch (SQLException ex) {
            Logger.getLogger(AddCentre2Controller.class.getName()).log(Level.SEVERE, null, ex);
            
             }
             return centresList;
        }
       public void showcentre(){
         centresList=getCentresList();
         colID.setCellValueFactory(new PropertyValueFactory<Centre,Integer>("id"));
         colNom.setCellValueFactory(new PropertyValueFactory<Centre,String>("nom_centre"));
           colADR.setCellValueFactory(new PropertyValueFactory<Centre,String>("adresse"));
           colSer.setCellValueFactory(new PropertyValueFactory<Centre,String>("services"));
           colTel.setCellValueFactory(new PropertyValueFactory<Centre,Integer>("num_tel"));
           colMail.setCellValueFactory(new PropertyValueFactory<Centre,String>("e_mail"));
         tvcentre.setItems(centresList);
           
       }
       @FXML
       public void updateCentre(ActionEvent event1){
          String adr= tfAdr.getText();
           if(selectedCentre != null){
           
            CentreCRUD pcd = new CentreCRUD();
             pcd.updateCentre(selectedCentre,adr);
            JOptionPane.showMessageDialog(null, "Centre modifie");
            showcentre();
             }
           else 
               JOptionPane.showMessageDialog(null, "selectionner a nouveau");
       }
        @FXML
        public void deleteCentre(ActionEvent event2){
          if(selectedCentre != null){
            CentreCRUD pcd = new CentreCRUD();
            pcd.supprimerCentre(selectedCentre);
            JOptionPane.showMessageDialog(null, "Centre supprime");
            selectedCentre = null;
            showcentre();
          }
          else 
              JOptionPane.showMessageDialog(null, "selectionner a nouveau");
             }
       @FXML
    public void test(){
          selectedCentre= (Centre) tvcentre.getSelectionModel().getSelectedItems().get(0);
            System.out.println("nom_centre"+selectedCentre.getId());
            tfNom.setText(selectedCentre.getNom_centre());
             tfAdr.setText(selectedCentre.getAdresse());
              tfService.setText(selectedCentre.getServices());
               tfNum.setText(""+selectedCentre.getNum_tel());
               tfemail.setText(selectedCentre.getE_mail());
    }
     
       @FXML
    private void search(KeyEvent event) {
        	
    // Wrap the ObservableList in a FilteredList (initially display all data).
      /*  FilteredList<Centre> filteredData = new FilteredList<>(centresList, b -> true);
		// 2. Set the filter Predicate whenever the filter changes.
		tfrech.textProperty().addListener((Observable, oldValue, newValue) -> {
                  
			filteredData.setPredicate(Centre -> {
				// If filter text is empty, display all persons.
                                  System.err.println("oldVaule");
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				
				// Compare first name and last name of every person with filter text.
				String lowerCaseFilter = newValue.toLowerCase();
				
            if (Centre.getNom_centre().toLowerCase().indexOf(lowerCaseFilter)!=-1){
                             return true; 
				} else if (Centre.getAdresse().toLowerCase().indexOf(lowerCaseFilter)!=-1) {
					return true; // Filter matches adresse.
				}
				
				    else  
				    	 return false; // Does not match.
			});
                        });
                        // 3. Wrap the FilteredList in a SortedList. 
		SortedList<Centre> sortedData = new SortedList<>(filteredData);
		// 4. Bind the SortedList comparator to the TableView comparator Otherwise, sorting the TableView would have no effect.
		sortedData.comparatorProperty().bind(tvcentre.comparatorProperty());
          
		// 5. Add sorted (and filtered) data to the table.
		tvcentre.setItems(sortedData);*/
         
                }
 @FXML
      public void welcome(ActionEvent event ) throws IOException{
      
    ((Node) (event.getSource())).getScene().getWindow().hide();
         FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/GeneralMainPackage/GeneralBackPage.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
    }





}
             
       
  
       
        

            
            
            
        
