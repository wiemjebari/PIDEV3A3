/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Etat;
import Entities.Randonnees;
import Entities.ReservationRandonnees;
import IServices.ServiceInterface;
import tools.MyConnection;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageViewBuilder;

/**
 *
 * @author ASUS
 */
public class ReservationService implements ServiceInterface<ReservationRandonnees> {
    private Connection con;
    private Statement ste;

    public ReservationService() {
        con = MyConnection.getInstance().getCnx();
    }

    /**
     *
     * @param t
     */
    @Override
    public void add(ReservationRandonnees t) throws SQLException {

           try {
               
            String requete = "INSERT INTO ReservationRandonnees (date,etat,id_user,id_randonnee,nbr_places) VALUES ('"+t.getDate()+"','"+t.getEtat()+"','"+t.getId_user()+"','"+t.getId_randonne()+"','"+t.getNbr_places()+"')";
            Statement st = con.createStatement();
            st.executeUpdate(requete);
            System.out.println("Reservation ajoutée");
            
        } 
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } 
        
         
    }

    @Override
    public void delete(int id) throws SQLException {
        try {
            String requete = "DELETE FROM ReservationRandonnees where id=?";
            PreparedStatement pst =con.prepareStatement(requete);
            pst.setInt(1, id);
            pst.executeUpdate();
            System.out.println("Réservation supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        }

    @Override
    public void update(ReservationRandonnees t) throws SQLException {
        try {
            String requete = "Update ReservationRandonnees set nbr_places='"+t.getNbr_places()+"' where id='"+t.getId()+"'";
            Statement st = con.createStatement();
            st.executeUpdate(requete);
            System.out.println("Reservation modifiée");
            
        } 
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
     public void updateAdmin(ReservationRandonnees t) throws SQLException {
        try {
            String requete = "Update ReservationRandonnees set etat='"+t.getEtat()+"' where id='"+t.getId()+"'";
            Statement st = con.createStatement();
            st.executeUpdate(requete);
            System.out.println("Reservation modifiée");
            
        } 
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List readAll() throws SQLException {
        List<ReservationRandonnees> l=new ArrayList<ReservationRandonnees>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select ReservationRandonnees.*,Randonnees.photo ,Randonnees.lieu,Randonnees.prix,utilisateur.nom from ReservationRandonnees inner join Randonnees on Randonnees.id=ReservationRandonnees.id_randonnee inner join utilisateur on utilisateur.id=ReservationRandonnees.id_user ");
        while(rs.next()){
            File file;
            file = new File(rs.getString("photo"));
            ImageView image=ImageViewBuilder.create()
                .image(new Image(file.toURI().toString()))
                .build();
            image.setFitHeight(100);
            image.setFitWidth(100);
            ReservationRandonnees r= new ReservationRandonnees(rs.getInt("id"),rs.getDate("date"),Etat.valueOf(rs.getString("etat")),rs.getString("nom"),rs.getString("lieu"),rs.getInt("nbr_places"),rs.getDouble("prix"),image,rs.getInt("id_user"),rs.getInt("id_randonnee"));
            l.add(r);
        }
        return l;
    }

    @Override
    public ReservationRandonnees getById(int id) throws SQLException {
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from ReservationRandonnees where id="+id);
        while(rs.next()){
            ReservationRandonnees r= new ReservationRandonnees(rs.getInt("id"),rs.getDate("date"),Etat.valueOf(rs.getString("etat")),rs.getInt("id_user"),rs.getInt("id_randonnee"),rs.getInt("nbr_places"));
            return r;
        }
        return null;
    }
    
     public List readByRandonnee(int id_randonnee) throws SQLException {
        List<ReservationRandonnees> l=new ArrayList<ReservationRandonnees>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from ReservationRandonnees where id_randonnee="+id_randonnee);
        while(rs.next()){
            ReservationRandonnees r= new ReservationRandonnees(rs.getInt("id"),rs.getDate("date"),Etat.valueOf(rs.getString("etat")),rs.getInt("id_user"),rs.getInt("id_randonnee"),rs.getInt("nbr_places"));
            l.add(r);
        }
        return l;
    }
     
     public int CalculNbr_ReservationExistant(int id_randonnee) throws SQLException{
         ste = con.createStatement();
         
        ResultSet rs=ste.executeQuery("select * from ReservationRandonnees where id_randonnee='"+id_randonnee+"' and etat='"+Etat.CONFIRME+"'");
        int compteur=0;
        while(rs.next()){
           compteur+=Integer.parseInt(rs.getString("nbr_places"));
        }
        return compteur;
    }
     
      public ReservationRandonnees getByIdEtat(int id) throws SQLException {
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select ReservationRandonnees.*,Randonnees.lieu,utilisateur.nom from ReservationRandonnees inner join Randonnees on Randonnees.id=ReservationRandonnees.id_randonnee inner join utilisateur on utilisateur.id=ReservationRandonnees.id_user where id='"+id+"' and etat='"+Etat.ENATTENTE+"'");
        while(rs.next()){
            ReservationRandonnees r= new ReservationRandonnees(rs.getInt("id"),rs.getDate("date"),Etat.valueOf(rs.getString("etat")),rs.getInt("id_user"),rs.getInt("id_randonnee"),rs.getInt("id_randonnee"));
            return r;
        }
        return null;
    }
      
     public List readByUser(int id_user) throws SQLException {
        List<ReservationRandonnees> l=new ArrayList<ReservationRandonnees>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select ReservationRandonnees.*,Randonnees.photo ,Randonnees.lieu,Randonnees.prix,utilisateur.nom from ReservationRandonnees inner join Randonnees on Randonnees.id=ReservationRandonnees.id_randonnee inner join utilisateur on utilisateur.id=ReservationRandonnees.id_user where id_user="+id_user);
        while(rs.next()){
            File file;
            file = new File(rs.getString("photo"));
            ImageView image=ImageViewBuilder.create()
                .image(new Image(file.toURI().toString()))
                .build();
            image.setFitHeight(100);
            image.setFitWidth(100);
            ReservationRandonnees r= new ReservationRandonnees(rs.getInt("id"),rs.getDate("date"),Etat.valueOf(rs.getString("etat")),rs.getString("nom"),rs.getString("lieu"),rs.getInt("nbr_places"),rs.getDouble("prix"),image,rs.getInt("id_user"),rs.getInt("id_randonnee"));
            l.add(r);
        }
        return l;
    }
     
     
      
     
}

    
