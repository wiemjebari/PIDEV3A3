/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Randonnees;
import Entities.ReservationRandonnees;
import IServices.ServiceInterface;
import tools.MyConnection;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.DatePicker;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageViewBuilder;

/**
 *
 * @author ASUS
 */
public class RandonneeService implements ServiceInterface<Randonnees>{
    
    private Connection con;
    private Statement ste;

    public RandonneeService() {
        con = MyConnection.getInstance().getCnx();
    }
    

    @Override
    public void add(Randonnees r) throws SQLException {
        
        String query="insert into `project`.`Randonnees`(`date`,`lieu`,`heure_depart`,`heure_retour`,`nbr_places`,`photo`,`prix`) Values (?,?,?,?,?,?,?)";

        PreparedStatement pst=con.prepareStatement(query);
        pst.setDate(1, r.getDate());
        pst.setString(2,r.getLieu());
        pst.setString(3, r.getHeure_depart());
        pst.setString(4, r.getHeure_retour());
        pst.setInt(5,r.getNbr_place());
        pst.setString(6, r.getPhoto());
        pst.setDouble(7, r.getPrix());
        pst.executeUpdate();
        
        /*ste = con.createStatement();             
        String query="insert into `project`.`Randonnees`(`date`,`lieu`,`heure_depart`,`heure_retour`,`nbr_places`,`photo`,`prix`) Values ('"+r.getDate()+"','"+r.getLieu()+"','"+r.getHeure_depart()+"','"+r.getHeure_retour()+"','"+r.getNbr_place()+"','"+r.getPhoto()+"','"+r.getPrix()+"')";
        ste.execute(query);*/
        System.out.println("randonne ajouté");
    }

    @Override
    public void delete(int id) throws SQLException {
        if(getById(id)!=null){
            
            ReservationService rs=new ReservationService();
            List<ReservationRandonnees> listeResevation= new ArrayList<ReservationRandonnees>();
            listeResevation=rs.readByRandonnee(id);
            for(ReservationRandonnees r:listeResevation){
                rs.delete(r.getId());
            }
            
            
       
            
           
            ste = con.createStatement();
            String query = "delete from randonnees where id="+id;
            ste.execute(query);
            System.out.println("randonne supprimé");
        }
        else{
            System.out.println("randonne n'existe pas");
        }
    }

    @Override
    public void update(Randonnees r) throws SQLException {
        if(getById(r.getId())!=null){
            
             String qy="update `project`.`Randonnees` set `date`=?,`lieu`=?,`heure_depart`=?,`heure_retour`=?,`nbr_places`=?,`photo`=?,`prix`=? where id=?";

        PreparedStatement pst=con.prepareStatement(qy);
        pst.setDate(1, r.getDate());
        pst.setString(2,r.getLieu());
        pst.setString(3, r.getHeure_depart());
        pst.setString(4, r.getHeure_retour());
        pst.setInt(5,r.getNbr_place());
        pst.setString(6, r.getPhoto());
        pst.setDouble(7, r.getPrix());
        pst.setDouble(8, r.getId());
        pst.executeUpdate();
            
            /*ste = con.createStatement();
            String query = "update randonnees Set date='"+r.getDate()+"',Lieu='"+r.getLieu()+"',heure_depart='"+r.getHeure_depart()+"',heure_retour='"+r.getHeure_retour()+"',photo='"+r.getPhoto()+"',nbr_places='"+r.getNbr_place()+"' ,prix='"+r.getPrix()+"' where id='"+r.getId()+"'";
            ste.execute(query);*/
            System.out.println("randonnee modifiée");
        }
        else{
            System.out.println("randonnee n'existe pas");
        }
    }

    @Override
    public List<Randonnees> readAll() throws SQLException {
        List<Randonnees> l=new ArrayList<Randonnees>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from randonnees");
        while(rs.next()){
            File file;
            file = new File(rs.getString("photo"));
            ImageView image=ImageViewBuilder.create()
                .image(new Image(file.toURI().toString()))
                .build();
            image.setFitHeight(100);
            image.setFitWidth(100);

            Randonnees r= new Randonnees(rs.getInt("id"),rs.getDate("date"),rs.getString("lieu"),rs.getString("heure_depart"),rs.getString("heure_retour"),rs.getInt("nbr_places"),rs.getString("photo"),rs.getDouble("prix"),image);
            ReservationService reservationServ=new ReservationService();
            
            r.setNbr_restant( rs.getInt("nbr_places") - reservationServ.CalculNbr_ReservationExistant(rs.getInt("id")) );
            l.add(r);
        }
        return l;
    }

    @Override
    public Randonnees getById(int id) throws SQLException {
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from randonnees where id="+id);
        while(rs.next()){
            Randonnees r= new Randonnees(rs.getInt("id"),rs.getDate("date"),rs.getString("lieu"),rs.getString("heure_depart"),rs.getString("heure_retour"),rs.getInt("nbr_places"),rs.getString("photo"),rs.getDouble("prix"));
            ReservationService reservationServ=new ReservationService();
            
            r.setNbr_restant( rs.getInt("nbr_places") - reservationServ.CalculNbr_ReservationExistant(rs.getInt("id")) );
            return r;
        }
        return null;
    }
    
    public List<Randonnees> recherche(String str) throws SQLException {
        List<Randonnees> l=new ArrayList<Randonnees>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from randonnees where lieu like '"+str+"%'");
        while(rs.next()){
            File file;
            file = new File(rs.getString("photo"));
            ImageView image=ImageViewBuilder.create()
                .image(new Image(file.toURI().toString()))
                .build();
            image.setFitHeight(100);
            image.setFitWidth(100);
            Randonnees r= new Randonnees(rs.getInt("id"),rs.getDate("date"),rs.getString("lieu"),rs.getString("heure_depart"),rs.getString("heure_retour"),rs.getInt("nbr_places"),rs.getString("photo"),rs.getDouble("prix"),image);
            ReservationService reservationServ=new ReservationService();
            
            r.setNbr_restant( rs.getInt("nbr_places") - reservationServ.CalculNbr_ReservationExistant(rs.getInt("id")) );
            l.add(r);
        }
        return l;
    }
    
   public double calculGain(int id_randonnee) throws SQLException{
       double prix=getById(id_randonnee).getPrix();
       
       ReservationService reservationServ=new ReservationService();
       int nbr_reservation=reservationServ.CalculNbr_ReservationExistant(id_randonnee);
       double Gain=prix*nbr_reservation;
       
       return Gain;
   }
   
   public List<Randonnees> FiltrePrix(double prixMax) throws SQLException {
        List<Randonnees> l=new ArrayList<Randonnees>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from randonnees where prix < '"+prixMax+"%' order by prix desc");
        while(rs.next()){
            File file;
            file = new File(rs.getString("photo"));
            ImageView image=ImageViewBuilder.create()
                .image(new Image(file.toURI().toString()))
                .build();
            image.setFitHeight(100);
            image.setFitWidth(100);
            Randonnees r= new Randonnees(rs.getInt("id"),rs.getDate("date"),rs.getString("lieu"),rs.getString("heure_depart"),rs.getString("heure_retour"),rs.getInt("nbr_places"),rs.getString("photo"),rs.getDouble("prix"),image);
            ReservationService reservationServ=new ReservationService();
            
            r.setNbr_restant( rs.getInt("nbr_places") - reservationServ.CalculNbr_ReservationExistant(rs.getInt("id")) );
            l.add(r);
        }
        return l;
    }
    
    public List getLieux() throws SQLException {
        List<String> l=new ArrayList<String>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from Randonnees");
        while(rs.next()){
            l.add(rs.getString("lieu"));
        }
        return l;
    }
    
    public Randonnees getByLieu(String lieu) throws SQLException {
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from randonnees where lieu='"+lieu+"'");
        while(rs.next()){
            File file;
            file = new File(rs.getString("photo"));
            ImageView image=ImageViewBuilder.create()
                .image(new Image(file.toURI().toString()))
                .build();
            image.setFitHeight(100);
            image.setFitWidth(100);
            Randonnees r= new Randonnees(rs.getInt("id"),rs.getDate("date"),rs.getString("lieu"),rs.getString("heure_depart"),rs.getString("heure_retour"),rs.getInt("nbr_places"),rs.getString("photo"),rs.getDouble("prix"),image);
            ReservationService reservationServ=new ReservationService();
            
            r.setNbr_restant( rs.getInt("nbr_places") - reservationServ.CalculNbr_ReservationExistant(rs.getInt("id")) );
            return r;
        }
        return null;
    }
    
    
    
}
