/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Avis;
import Entities.Randonnees;
import IServices.ServiceInterface;
import tools.MyConnection;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageViewBuilder;

/**
 *
 * @author ASUS
 */
public class AvisService implements ServiceInterface<Avis> {
    
    private Connection con;
    private Statement ste;

    public  AvisService() {
        con = MyConnection.getInstance().getCnx();
    }

    @Override
    public void add(Avis t) throws SQLException {
        String query="insert into `project`.`Avis`(`note`,`id_user`) Values (?,?)";

        PreparedStatement pst=con.prepareStatement(query);
        pst.setInt(1, t.getNote());
        pst.setInt(2,t.getId_user());
        pst.executeUpdate();
    }

    @Override
    public void delete(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Avis t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Avis> readAll() throws SQLException {
        List<Avis> l=new ArrayList<Avis>();
        ste = con.createStatement();
        ResultSet rs=ste.executeQuery("select * from Avis");
        while(rs.next()){         
            Avis a=new Avis(rs.getInt("id"),rs.getInt("note"),rs.getInt("id_user"));
            l.add(a);
        }
        return l;
    }

    @Override
    public Avis getById(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
