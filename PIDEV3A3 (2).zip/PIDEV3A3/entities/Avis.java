/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author ASUS
 */
public class Avis {
    private int id;
    private int note;
    private int id_user;

    public Avis() {
    }

    public Avis(int note, int id_user) {
        this.note = note;
        this.id_user = id_user;
    }

    public Avis(int id, int note, int id_user) {
        this.id = id;
        this.note = note;
        this.id_user = id_user;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNote() {
        return note;
    }

    public void setNote(int note) {
        this.note = note;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }
    
    
    
}
