/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.sql.Date;
import javafx.scene.image.ImageView;

/**
 *
 * @author ASUS
 */
public class ReservationRandonnees {
    
    private int id;
    private Date date;
    private Etat etat;
    private int nbr_places;
    private int id_user;
    private int id_randonne;
    
    private String nom_user;
    private String lieu_randonnee;
    private double prix_randonnee;
    private ImageView photo;

    public ReservationRandonnees() {
    }

    public ReservationRandonnees(int id, Date date, Etat etat, int id_user, int id_randonne,int nbr_places) {
        this.id = id;
        this.date = date;
        this.etat = etat;
        this.id_user = id_user;
        this.id_randonne = id_randonne;
        this.nbr_places = nbr_places;
    }

    public ReservationRandonnees(Date date, Etat etat, int id_user, int id_randonne,int nbr_places) {
        this.date = date;
        this.etat = etat;
        this.id_user = id_user;
        this.id_randonne = id_randonne;
        this.nbr_places = nbr_places;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Etat getEtat() {
        return etat;
    }

    public void setEtat(Etat etat) {
        this.etat = etat;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public int getId_randonne() {
        return id_randonne;
    }

    public void setId_randonne(int id_randonne) {
        this.id_randonne = id_randonne;
    }

    public String getNom_user() {
        return nom_user;
    }

    public void setNom_user(String nom_user) {
        this.nom_user = nom_user;
    }

    public String getLieu_randonnee() {
        return lieu_randonnee;
    }

    public void setLieu_randonnee(String lieu_randonnee) {
        this.lieu_randonnee = lieu_randonnee;
    }

    public int getNbr_places() {
        return nbr_places;
    }

    public void setNbr_places(int nbr_places) {
        this.nbr_places = nbr_places;
    }

    public double getPrix_randonnee() {
        return prix_randonnee;
    }

    public void setPrix_randonnee(double prix_randonnee) {
        this.prix_randonnee = prix_randonnee;
    }

    public ImageView getPhoto() {
        return photo;
    }

    public void setPhoto(ImageView photo) {
        this.photo = photo;
    }
    
    

    public ReservationRandonnees(int id, Date date, Etat etat, String nom_user, String lieu_randonnee,int nbr_places,double prix_randonnee,ImageView photo,int id_user, int id_randonne) {
        this.id = id;
        this.date = date;
        this.etat = etat;
        this.nom_user = nom_user;
        this.lieu_randonnee = lieu_randonnee;
        this.nbr_places = nbr_places;
        this.prix_randonnee = prix_randonnee;
        this.photo = photo;
        this.id_user = id_user;
        this.id_randonne = id_randonne;
    }

    @Override
    public String toString() {
        return "ReservationRandonnees{" + "id=" + id + ", date=" + date + ", etat=" + etat + ", nbr_places=" + nbr_places + ", id_user=" + id_user + ", id_randonne=" + id_randonne + ", nom_user=" + nom_user + ", lieu_randonnee=" + lieu_randonnee + ", prix_randonnee=" + prix_randonnee + ", photo=" + photo + '}';
    }

    
    

    

   

}

