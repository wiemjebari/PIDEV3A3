/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.time.LocalDate;
import java.util.GregorianCalendar;



/**
 *
 * @author asmab
 */
public class Reservation_Centre {
    
        
   public int id_reservation	;//cle primaire
   public String nom_centre;	
   public String services;//cle etrangere
   int prix;
   
           public String date; 
           public Reservation_Centre(){
               
           }

    public Reservation_Centre( int id_reservation,String nom_centre, String services, String date,int prix) {
       this.id_reservation=  id_reservation;
        this.nom_centre = nom_centre;
        this.services = services;
        this.date = date;
     this.prix=prix;
    }

    public int getId_reservation() {
        return id_reservation;
    }

    public void setId_reservation(int id_reservation) {
        this.id_reservation = id_reservation;
    }

    public String getNom_centre() {
        return nom_centre;
    }

    public void setNom_centre(String nom_centre) {
        this.nom_centre = nom_centre;
    }

    public String getServices() {
        return services;
    }

    public void setServices(String services) {
        this.services = services;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

 
    
    @Override
    public String toString() {
        return "Reservation_Centre{" + "id_reservation=" + id_reservation + ", nom_centre=" + nom_centre + ", services=" + services + ", prix=" + prix + ", date=" + date + '}';
    }


   

   
    
           
}

