/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author asmab
 */
public class Centre {
    public int id;
    private String nom_centre;
    private String adresse;
   private String services;
    private int num_tel;
    private String e_mail;

    

    public Centre() {
    }

    public Centre( int id,String nom_centre, String adresse, String services, int num_tel, String e_mail) {
       this.id=id;
        this.nom_centre = nom_centre;
        this.adresse = adresse;
        this.services = services;
        this.num_tel = num_tel;
        this.e_mail = e_mail;
    }

//    public Centre(int aInt, String string, String string0, String string1, int aInt0, String string2) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

   

   
public int getId() {
        return id;
    }
    public String getNom_centre() {
        return nom_centre;
    }

    public String getAdresse() {
        return adresse;
    }

    public int getNum_tel() {
        return num_tel;
    }

    public String getE_mail() {
        return e_mail;
    }

    public String getServices() {
        return services;
    }

    public void setServices(String services) {
        this.services = services;
    }

   

    public void setNom_centre(String nom_centre) {
        this.nom_centre = nom_centre;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setNum_tel(int num_tel) {
        this.num_tel = num_tel;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    @Override
    public String toString() {
        return "Centre{" + " nom_centre=" + nom_centre + ", adresse=" + adresse + ", num_tel=" + num_tel + ", e_mail=" + e_mail + ", services=" + services + '}';
    }

    

    
    
    
    
}

