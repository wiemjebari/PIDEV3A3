/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.sql.Date;
import javafx.scene.image.ImageView;

/**
 *
 * @author ASUS
 */
public class Randonnees {
    private int id;
    private java.sql.Date date;
    private String lieu;
    private String heure_depart;
    private String heure_retour;
    private int nbr_place;
    private String photo;
    private double prix;
    
    private ImageView photoV;
    private int nbr_restant;
    
    public Randonnees() {
    }

    public Randonnees(java.sql.Date date, String lieu, String heure_depart, String heure_retour, int nbr_place, String photo,double prix) {
        this.date = date;
        this.lieu = lieu;
        this.heure_depart = heure_depart;
        this.heure_retour = heure_retour;
        this.nbr_place = nbr_place;
        this.photo = photo;
        this.prix = prix;
    }
    
   
    

    public Randonnees(int id,java.sql.Date date, String lieu, String heure_depart, String heure_retour, int nbr_place, String photo,double prix,ImageView photoV) {
        this.id = id;
        this.date = date;
        this.lieu = lieu;
        this.heure_depart = heure_depart;
        this.heure_retour = heure_retour;
        this.nbr_place = nbr_place;
        this.photoV = photoV;
        this.photo=photo;
        this.prix = prix;
    }
     public Randonnees(int id,java.sql.Date date, String lieu, String heure_depart, String heure_retour, int nbr_place, String photo,double prix) {
        this.id = id;
        this.date = date;
        this.lieu = lieu;
        this.heure_depart = heure_depart;
        this.heure_retour = heure_retour;
        this.nbr_place = nbr_place;
        this.photo=photo;
        this.prix = prix;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public java.sql.Date getDate() {
        return date;
    }

    public void setDate(java.sql.Date date) {
        this.date = date;
    }

    public String getLieu() {
        return lieu;
    }

    public void setLieu(String lieu) {
        this.lieu = lieu;
    }

    public String getHeure_depart() {
        return heure_depart;
    }

    public void setHeure_depart(String heure_depart) {
        this.heure_depart = heure_depart;
    }

    public String getHeure_retour() {
        return heure_retour;
    }

    public void setHeure_retour(String heure_retour) {
        this.heure_retour = heure_retour;
    }

    public int getNbr_place() {
        return nbr_place;
    }

    public void setNbr_place(int nbr_place) {
        this.nbr_place = nbr_place;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public ImageView getPhotoV() {
        return photoV;
    }

    public void setPhotoV(ImageView photoV) {
        this.photoV = photoV;
    }

    public int getNbr_restant() {
        return nbr_restant;
    }

    public void setNbr_restant(int nbr_restant) {
        this.nbr_restant = nbr_restant;
    }
    
    
    
    
    @Override
    public String toString() {
        return "Randonnees{" + "id=" + id + ", date=" + date + ", lieu=" + lieu + ", heure_depart=" + heure_depart + ", heure_retour=" + heure_retour + ", nbr_place=" + nbr_place + ", photo=" + photo + ", prix=" + prix +'}';
    }
    
    
    
}
